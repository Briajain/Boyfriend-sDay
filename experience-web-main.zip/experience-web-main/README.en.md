# 💌 Romantic Experience Web — Boyfriend's Day Edition

<p align="center">
  <a href="https://github.com/lucas-hochmann-rosa/romantic-experience-web">
    <img src="https://img.shields.io/badge/GitHub-romantic--experience--web-181717?style=for-the-badge&logo=github" alt="Repository GitHub">
  </a>
  <a href="https://www.linkedin.com/in/lucas-hochmann-rosa">
    <img src="https://img.shields.io/badge/LinkedIn-Lucas_Hochmann_Rosa-0A66C2?style=for-the-badge&logo=linkedin" alt="LinkedIn Lucas Hochmann Rosa">
  </a>
  <a href="https://lucas-hochmann-rosa.github.io/romantic-experience-web/">
    <img src="https://img.shields.io/badge/Page-Web-4f8edb?style=for-the-badge" alt="Web Page">
  </a>
  <a href="./LICENSE">
    <img src="https://img.shields.io/badge/License-MIT-2ea44f?style=for-the-badge" alt="MIT License">
  </a>
</p>

<p align="center"><a href="README.md">🇧🇷 Português</a> · 🇺🇸 English</p>

> A blue-toned romantic experience for **Boyfriend's Day (3 October)** — built as a static website with HTML, CSS/SCSS, and vanilla JavaScript, featuring a classic-roadster motorcycle mini-game, a live relationship counter, an interactive letter, and a sky full of wishes.

---

## 📌 Overview

**Romantic Experience Web** was built as an interactive digital gift, focused on performance, simple maintenance and a fully static setup.

Main flow:

1. Welcome screen — **"Happy Boyfriend's Day, My Love 💙"** — with an **Open Your Surprise 💙** button.
2. **The Ride** — a motorcycle mini-game (keyboard and touch controls). Finishing the ride unlocks the next section.
3. **Our Time** — a live counter since 22 April 2026, 9:48 AM (IST), showing years, months, days, hours, minutes and seconds.
4. **Letter** — a love letter in a blue envelope with a heart seal, full content in `letter.json`.
5. **Wishes** — a text-only wishes section with stars and shooting stars.
6. **Floating Spotify player** with "Khat — Navjot Ahuja" available throughout the experience.

---

## ✨ Key Features

- Welcome screen with a blue gradient, floating particles and experience unlocking.
- Canvas motorcycle mini-game (dodge the cones, reach 1000 m) with a distance HUD, progress bar and a personalized completion screen. Bumps are harmless — there is no way to lose, every ride reaches the finish line.
- "Our Time" section locked until the mini-game is completed.
- Real-time relationship counter with correct calendar math (variable month lengths, leap years) in the `Asia/Kolkata` time zone.
- Letter with an envelope-opening animation, ice-blue paper, internal scrolling and content loaded from `assets/data/letter.json`.
- Wishes section with animated phrases, twinkling stars and shooting stars (respecting `prefers-reduced-motion`).
- Floating player with the official Spotify embed plus a direct link to the track.

---

## 🧭 Table of Contents

- [Architecture](#-architecture)
- [Tech Stack](#-tech-stack)
- [Project Ground Rules](#-project-ground-rules)
- [Requirements](#-requirements)
- [Installation](#-installation)
- [Usage](#-usage)
- [Static Publishing (GitHub Pages)](#-static-publishing-github-pages)
- [Disclaimer](#-disclaimer)
- [Author](#-author)
- [License](#-license)

---

## 🏗️ Architecture

```text
romantic-experience-web/
├── index.html
├── assets/
│   ├── audio/                          # empty — the song now uses the Spotify embed
│   ├── css/
│   │   ├── main.css                    # Compiled from assets/scss/main.scss
│   │   ├── sections.css                # Plain CSS, hand-maintained
│   │   ├── animations.css              # Plain CSS, hand-maintained
│   │   └── responsive.css              # Plain CSS, hand-maintained
│   ├── scss/
│   │   └── main.scss                   # The project's only real Sass source
│   ├── data/
│   │   └── letter.json
│   ├── img/
│   │   ├── favicon.svg
│   │   └── decorative/
│   └── js/
│       ├── main.js                     # orchestrates everything + Spotify player + letter
│       ├── intro.js
│       ├── game.js                     # motorcycle mini-game
│       ├── counter.js
│       ├── effects.js
│       └── meteor.js
├── LICENSE
└── README.md
```

### Organization

- **`index.html`** → single structure holding every section of the experience
- **`assets/js/`** → one module per section (`window.MemoriesX.init()`), orchestrated by `main.js`
- **`assets/data/`** → dynamic content (letter) consumed via `fetch`, with a local fallback if it fails
- **`assets/scss/main.scss`** → the only real Sass source; the remaining files in `assets/css/` are plain CSS, written and maintained directly (no Sass source)

---

## 🧰 Tech Stack

- Semantic HTML5
- CSS3 + Sass (`main.scss`, compiled locally - e.g. with VS Code's "Live Sass Compile" extension or `npx sass`)
- Vanilla JavaScript (no framework, no build step) + Canvas 2D for the mini-game
- The official Spotify embed for the music (no external dependencies)

---

## 📐 Project Ground Rules

- Identifiers, classes, IDs, JSON keys, and function names stay in English.
- All visible text (titles, buttons, letter paragraphs) stays in English: it's the experience itself, written for one specific person.
- No build step is required to run the site - only the Sass needs manual compilation when editing `main.scss`.

---

## ⚙️ Requirements

- Any static HTTP server for local development (e.g. `npx serve`)
- Node.js only if recompiling `assets/scss/main.scss` (via `npx sass`)

---

## 🔧 Installation

```bash
git clone https://github.com/lucas-hochmann-rosa/romantic-experience-web.git
cd romantic-experience-web
npx serve .
```

Open:

- `http://localhost:3000/index.html`

---

## ▶️ Usage

To recompile the main stylesheet after editing `assets/scss/main.scss`:

```bash
npx sass assets/scss/main.scss assets/css/main.css
```

The other files in `assets/css/` (`sections.css`, `animations.css`, `responsive.css`) are plain CSS and can be edited directly, with no compilation step.

---

## 🌐 Static Publishing (GitHub Pages)

The project is published as a static site directly by GitHub Pages, from the `develop` branch.

---

## ⚠️ Disclaimer

This is a personal gift, with text meant for one specific person. No personal photographs are included in this site. The code is open for reference and reuse of its structure, but the content (letter, phrases) is private. The song is played only through the official Spotify embed/link — no audio file is distributed.

---

## 👨‍💻 Author

**Lucas Hochmann Rosa**

- GitHub: <https://github.com/lucas-hochmann-rosa>
- Page: <https://lucas-hochmann-rosa.github.io/romantic-experience-web/>
- LinkedIn: <https://www.linkedin.com/in/lucas-hochmann-rosa>

---

## 📄 License

Licensed under MIT. Feel free to use, modify, and distribute, while keeping the copyright notice and crediting **Lucas Hochmann Rosa**.

See [LICENSE](./LICENSE).

---
