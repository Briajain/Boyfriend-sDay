"""Local dev server for the Boyfriend's Day site.

Same as `python -m http.server`, but sends `Cache-Control: no-store`
so browsers (yours and your friend's) always load the latest files.
Run:  python serve.py 8642
"""

import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer


class NoCacheHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8642
    server = ThreadingHTTPServer(("127.0.0.1", port), NoCacheHandler)
    print(f"Serving with no-store caching on http://127.0.0.1:{port}")
    server.serve_forever()


if __name__ == "__main__":
    main()
