# 💌 Romantic Experience Web — Boyfriend's Day Edition

<p align="center">
  <a href="https://github.com/lucas-hochmann-rosa/romantic-experience-web">
    <img src="https://img.shields.io/badge/GitHub-romantic--experience--web-181717?style=for-the-badge&logo=github" alt="GitHub do repositório">
  </a>
  <a href="https://www.linkedin.com/in/lucas-hochmann-rosa">
    <img src="https://img.shields.io/badge/LinkedIn-Lucas_Hochmann_Rosa-0A66C2?style=for-the-badge&logo=linkedin" alt="LinkedIn Lucas Hochmann Rosa">
  </a>
  <a href="https://lucas-hochmann-rosa.github.io/romantic-experience-web/">
    <img src="https://img.shields.io/badge/P%C3%A1gina-Web-4f8edb?style=for-the-badge" alt="Página Web">
  </a>
  <a href="./LICENSE">
    <img src="https://img.shields.io/badge/Licen%C3%A7a-MIT-2ea44f?style=for-the-badge" alt="Licença MIT">
  </a>
</p>

<p align="center">🇧🇷 Português · <a href="README.en.md">🇺🇸 English</a></p>

> Experiência romântica em tons de azul para o **Dia do Namorado (3 de outubro)** — estática em HTML, CSS/SCSS e JavaScript puro, com um mini-game de motocicleta inspirado em roadsters clássicos, contador de tempo ao vivo, carta interativa e um céu de desejos.

---

## 📌 Visão Geral

O **Romantic Experience Web** foi estruturado como um presente digital interativo, com foco em performance, manutenção simples e execução 100% estática.

Fluxo principal:

1. Tela de entrada — **“Happy Boyfriend’s Day, My Love 💙”** — com botão **Open Your Surprise 💙**.
2. **The Ride** — mini-game de motocicleta (controles por teclado e toque). Concluir o percurso desbloqueia a seção seguinte.
3. **Our Time** — contador ao vivo desde 22 de abril de 2026, 9:48 AM (IST), com anos, meses, dias, horas, minutos e segundos.
4. **Letter** — carta em envelope azul com selo de coração, conteúdo completo em `letter.json`.
5. **Wishes** — seção de desejos apenas textual, com estrelas e estrelas cadentes.
6. **Player flutuante do Spotify** com “Khat — Navjot Ahuja” disponível durante toda a experiência.

---

## ✨ Funcionalidades

- Tela de entrada com degradê azul, partículas flutuantes e desbloqueio da experiência.
- Mini-game de motocicleta em canvas (desvie dos cones, alcance 1000 m) com pontuação, barra de progresso e tela de conclusão personalizada. Batidas são inofensivas — não há como perder, toda corrida termina na linha de chegada.
- Seção “Our Time” bloqueada até a conclusão do mini-game.
- Contador de relacionamento em tempo real, com cálculo de calendário correto (meses de tamanhos diferentes, anos bissextos) e fuso `Asia/Kolkata`.
- Carta com animação de envelope, papel azul-gelo, rolagem interna e conteúdo carregado de `assets/data/letter.json`.
- Seção de desejos com frases animadas, estrelas e estrelas cadentes (respeitando `prefers-reduced-motion`).
- Player flutuante com o embed oficial do Spotify + link direto para a faixa.

---

## 🧭 Sumário

- [Arquitetura](#-arquitetura)
- [Tecnologias](#-tecnologias)
- [Regras de construção do projeto](#-regras-de-construção-do-projeto)
- [Requisitos](#-requisitos)
- [Instalação](#-instalação)
- [Execução](#-execução)
- [Publicação Estática (GitHub Pages)](#-publicação-estática-github-pages)
- [Avisos](#-avisos)
- [Autor](#-autor)
- [Licença](#-licença)

---

## 🏗️ Arquitetura

```text
romantic-experience-web/
├── index.html
├── assets/
│   ├── audio/                          # vazia — a música agora usa o embed do Spotify
│   ├── css/
│   │   ├── main.css                    # Compilado a partir de assets/scss/main.scss
│   │   ├── sections.css                # CSS puro, mantido a mão
│   │   ├── animations.css              # CSS puro, mantido a mão
│   │   └── responsive.css              # CSS puro, mantido a mão
│   ├── scss/
│   │   └── main.scss                   # Única fonte Sass real do projeto
│   ├── data/
│   │   └── letter.json
│   ├── img/
│   │   ├── favicon.svg
│   │   └── decorative/
│   └── js/
│       ├── main.js                     # orquestra tudo + player Spotify + carta
│       ├── intro.js
│       ├── game.js                     # mini-game da motocicleta
│       ├── counter.js
│       ├── effects.js
│       └── meteor.js
├── LICENSE
└── README.md
```

### Organização

- **`index.html`** → estrutura única de todas as seções da experiência
- **`assets/js/`** → um módulo por seção (`window.MemoriesX.init()`), orquestrados por `main.js`
- **`assets/data/`** → conteúdo dinâmico (carta) consumido via `fetch`, com fallback local em caso de falha
- **`assets/scss/main.scss`** → única fonte Sass; os demais arquivos em `assets/css/` são CSS puro, escritos e mantidos diretamente (sem fonte Sass)

---

## 🧰 Tecnologias

- HTML5 semântico
- CSS3 + Sass (`main.scss`, compilado localmente - por exemplo, com a extensão "Live Sass Compile" do VS Code ou `npx sass`)
- JavaScript puro (sem framework, sem build step) + Canvas 2D para o mini-game
- Embed oficial do Spotify para a música (sem dependências externas)

---

## 📐 Regras de construção do projeto

- Identificadores, classes, IDs, chaves de JSON e nomes de função ficam em inglês.
- Todo o texto visível (títulos, botões, frases da carta) fica em inglês: é a experiência em si, escrita para uma pessoa específica.
- Nenhum passo de build é necessário para rodar o site - só o Sass precisa ser compilado manualmente ao editar `main.scss`.

---

## ⚙️ Requisitos

- Qualquer servidor HTTP estático para desenvolvimento local (ex.: `npx serve`)
- Node.js apenas se for recompilar `assets/scss/main.scss` (via `npx sass`)

---

## 🔧 Instalação

```bash
git clone https://github.com/lucas-hochmann-rosa/romantic-experience-web.git
cd romantic-experience-web
npx serve .
```

Acesse:

- `http://localhost:3000/index.html`

---

## ▶️ Execução

Para recompilar o CSS principal após alterar `assets/scss/main.scss`:

```bash
npx sass assets/scss/main.scss assets/css/main.css
```

Os demais arquivos em `assets/css/` (`sections.css`, `animations.css`, `responsive.css`) são CSS puro e podem ser editados diretamente, sem compilação.

---

## 🌐 Publicação Estática (GitHub Pages)

O projeto é publicado como site estático diretamente pelo GitHub Pages, a partir da branch `develop`.

---

## ⚠️ Avisos

Este é um presente pessoal, com texto voltado a uma pessoa específica. Nenhuma fotografia pessoal é incluída neste site. O código é aberto para consulta e reaproveitamento da estrutura, mas o conteúdo (carta, frases) é particular. A música é reproduzida apenas pelo embed/link oficial do Spotify — nenhum arquivo de áudio é distribuído.

---

## 👨‍💻 Autor

**Lucas Hochmann Rosa**

- GitHub: <https://github.com/lucas-hochmann-rosa>
- Página: <https://lucas-hochmann-rosa.github.io/romantic-experience-web/>
- LinkedIn: <https://www.linkedin.com/in/lucas-hochmann-rosa>

---

## 📄 Licença

Licenciado sob MIT. Sinta-se livre para usar, modificar e distribuir, mantendo o aviso de copyright e atribuindo crédito a **Lucas Hochmann Rosa**.

Consulte [LICENSE](./LICENSE).

---
