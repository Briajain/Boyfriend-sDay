from IPython.display import display, HTML

def launch_dip_engine_v5():
    html_code = """
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700;900&family=Fira+Code:wght@400;600&display=swap');

        #dip_app * { box-sizing: border-box; user-select: none; margin: 0; padding: 0; }

        #dip_app {
            position: relative; width: 100%; height: 880px; background: #03070d;
            border: 2px solid #00ff88; border-radius: 16px; overflow: hidden;
            font-family: 'Fira Code', monospace; box-shadow: 0 0 50px rgba(0, 255, 136, 0.25), inset 0 0 40px rgba(0, 0, 0, 0.85);
            color: #e0f2fe;
        }

        /* Subtle scanlines holographic overlay */
        #dip_app::before {
            content: " ";
            position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            background: linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%), linear-gradient(90deg, rgba(0, 255, 136, 0.02), rgba(0, 0, 0, 0), rgba(56, 189, 248, 0.02));
            background-size: 100% 3px, 6px 100%;
            pointer-events: none; z-index: 15; opacity: 0.6;
        }

        #sidebar {
            position: absolute; top: 0; left: 0; width: 300px; height: 100%;
            background: rgba(6, 14, 26, 0.92); backdrop-filter: blur(14px); z-index: 20;
            border-right: 2px solid #00ff88; overflow-y: auto; padding: 15px; color: #e0f2fe; scroll-behavior: smooth;
            box-shadow: 10px 0 30px rgba(0, 0, 0, 0.7);
        }

        #sidebar::-webkit-scrollbar { width: 4px; }
        #sidebar::-webkit-scrollbar-thumb { background: #00ff88; border-radius: 2px; box-shadow: 0 0 8px #00ff88; }

        .sidebar-title {
            font-family: 'Orbitron', sans-serif; font-size: 14px; font-weight: 900; color: #00ff88;
            text-align: center; letter-spacing: 2px; padding-bottom: 10px; border-bottom: 2px solid #00ff88;
            position: sticky; top: 0; background: rgba(6, 14, 26, 0.98); z-index: 30; margin-bottom: 12px;
            text-shadow: 0 0 10px #00ff88, 0 0 20px rgba(0, 255, 136, 0.4);
        }

        .unit-header {
            font-family: 'Orbitron', sans-serif; font-size: 11px; font-weight: 700; color: #38bdf8;
            margin-top: 14px; margin-bottom: 6px; letter-spacing: 1px;
            text-shadow: 0 0 8px rgba(56, 189, 248, 0.4);
            display: flex; align-items: center; gap: 6px;
        }

        .unit-header::before {
            content: "▶"; font-size: 8px; color: #00ff88;
        }

        .menu-item {
            padding: 8px 12px; margin: 4px 0; background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(0, 255, 136, 0.18); border-radius: 6px; font-size: 11px;
            cursor: pointer; transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); color: #94a3b8;
            display: flex; justify-content: space-between; align-items: center;
        }

        .menu-item:hover {
            border-color: #00ff88; color: #00ff88; background: rgba(0, 255, 136, 0.08);
            box-shadow: 0 0 12px rgba(0, 255, 136, 0.3); transform: translateX(3px);
        }

        .menu-item.active {
            background: linear-gradient(90deg, #00ff88, #10b981); color: #020617; font-weight: bold;
            border-color: #00ff88; box-shadow: 0 0 18px rgba(0, 255, 136, 0.7); transform: translateX(5px);
        }

        #viewport {
            position: absolute; top: 0; left: 300px; width: calc(100% - 300px); height: 100%;
            display: flex; align-items: center; justify-content: center;
            background: radial-gradient(circle at center, #0b1728 0%, #020617 100%);
            overflow: hidden;
        }

        #viewport_stage {
            position: relative; width: 640px; height: 480px; max-width: 95%; max-height: 95%;
            aspect-ratio: 4 / 3; border-radius: 12px; overflow: hidden;
            box-shadow: 0 0 35px rgba(0, 255, 136, 0.25), 0 0 60px rgba(0, 0, 0, 0.85);
            border: 2px solid rgba(0, 255, 136, 0.4);
            background: #000;
        }

        #output_canvas {
            position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            transform: scaleX(-1); object-fit: cover; z-index: 1;
        }

        #gl_canvas {
            position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            transform: scaleX(-1); pointer-events: none; z-index: 2; object-fit: cover;
        }

        #top_hud {
            position: absolute; top: 20px; right: 20px; z-index: 30;
            background: rgba(6, 14, 26, 0.9); backdrop-filter: blur(14px);
            padding: 14px 18px; border: 1px solid #00ff88; border-radius: 10px; color: #00ff88;
            min-width: 340px; box-shadow: 0 0 25px rgba(0, 255, 136, 0.25);
        }

        .hud-row { display: flex; justify-content: space-between; font-size: 11px; margin-bottom: 4px; align-items: center; }
        .hud-val { color: #ffffff; font-weight: bold; }

        .param-bar-bg {
            width: 100%; height: 6px; background: rgba(255,255,255,0.1); border-radius: 3px;
            margin-top: 6px; overflow: hidden; border: 1px solid rgba(0,255,136,0.3);
        }

        .param-bar-fill {
            height: 100%; width: 50%; background: linear-gradient(90deg, #00ff88, #38bdf8);
            box-shadow: 0 0 10px #00ff88; transition: width 0.08s linear;
        }

        .hud-badge {
            display: inline-block; padding: 2px 7px; font-size: 9px; font-weight: bold;
            border-radius: 4px; font-family: 'Orbitron', sans-serif; letter-spacing: 0.5px;
        }
        .badge-active { background: rgba(0, 255, 136, 0.2); color: #00ff88; border: 1px solid #00ff88; }
        .badge-cyan { background: rgba(56, 189, 248, 0.2); color: #38bdf8; border: 1px solid #38bdf8; }

        #analytics_hud { position: absolute; bottom: 20px; right: 20px; z-index: 30; display: flex; gap: 14px; }

        .analytics-box {
            background: rgba(6, 14, 26, 0.9); backdrop-filter: blur(14px); padding: 12px 14px;
            border: 1px solid #00ff88; border-radius: 10px; color: #00ff88; font-size: 10px;
            text-align: center; box-shadow: 0 0 20px rgba(0,255,136,0.18);
        }

        #kernel_grid { display: grid; grid-template-columns: repeat(3, 36px); gap: 4px; margin-top: 6px; justify-content: center; }

        .kernel-cell {
            background: rgba(0, 255, 136, 0.1); border: 1px solid rgba(0, 255, 136, 0.4);
            padding: 6px 2px; color: #e0f2fe; font-size: 10px; border-radius: 4px; font-weight: 600;
        }

        .btn-clear {
            margin-top: 7px; padding: 4px 8px; background: rgba(244, 63, 94, 0.15);
            border: 1px solid #f43f5e; color: #f43f5e; border-radius: 4px; font-family: 'Orbitron', sans-serif;
            font-size: 9px; cursor: pointer; transition: all 0.2s ease; width: 100%;
        }
        .btn-clear:hover { background: #f43f5e; color: #fff; box-shadow: 0 0 10px #f43f5e; }

        .scroll-ind {
            position: absolute; left: 0; width: 300px; height: 28px; z-index: 25; pointer-events: none;
            opacity: 0; transition: opacity 0.2s; text-align: center; line-height: 28px;
            font-family: 'Orbitron', sans-serif; font-size: 10px; font-weight: bold; color: #00ff88;
        }
        #scroll_top_ind { top: 40px; background: linear-gradient(to bottom, rgba(0,255,136,0.4), transparent); }
        #scroll_bottom_ind { bottom: 0; background: linear-gradient(to top, rgba(0,255,136,0.4), transparent); }

        #hand_cursor {
            position: absolute; width: 28px; height: 28px; border: 2px solid #38bdf8;
            border-radius: 50%; pointer-events: none; z-index: 1000; transform: translate(-50%, -50%);
            display: none; background: rgba(56, 189, 248, 0.25); box-shadow: 0 0 20px #38bdf8, inset 0 0 8px #38bdf8;
            transition: border-color 0.15s, box-shadow 0.15s;
        }

        #hand_cursor.fist-active {
            border-color: #00ff88; background: rgba(0, 255, 136, 0.35); box-shadow: 0 0 25px #00ff88, inset 0 0 10px #00ff88;
        }

        #hand_cursor::after {
            content: ''; position: absolute; top: 50%; left: 50%; width: 6px; height: 6px;
            background: #ffffff; border-radius: 50%; transform: translate(-50%, -50%);
            box-shadow: 0 0 6px #ffffff;
        }
    </style>

    <div id="dip_app">
        <div id="sidebar">
            <div class="sidebar-title">⚡ AR SPATIAL DIP ENGINE</div>
            <div id="menu_tree"></div>
        </div>

        <div id="scroll_top_ind">▲ SCROLL UP</div>
        <div id="scroll_bottom_ind">▼ SCROLL DOWN</div>

        <div id="viewport">
            <div id="viewport_stage">
                <video id="video_feed" style="display:none;" autoplay playsinline muted></video>
                <canvas id="output_canvas" width="640" height="480"></canvas>
                <canvas id="gl_canvas" width="640" height="480"></canvas>
            </div>
        </div>

        <div id="top_hud">
            <div class="hud-row">
                <span>ACTIVE OPERATION:</span>
                <span id="active_op_label" class="hud-val">Color -> Gray</span>
            </div>
            <div class="hud-row">
                <span>TRIGGER STATE:</span>
                <span id="trigger_label" class="hud-val" style="color: #ef4444;">PASS-THROUGH (Open Hand)</span>
            </div>
            <div class="hud-row">
                <span>AR VFX PRESET:</span>
                <span id="vfx_preset_label" class="hud-badge badge-cyan">Chromatic Plasma</span>
            </div>
            <div class="hud-row">
                <span>3D AIR-PAINT:</span>
                <span id="paint_state_label" class="hud-badge badge-active">Standby</span>
            </div>

            <div style="margin-top: 10px; border-top: 1px dashed rgba(0,255,136,0.3); padding-top: 8px;">
                <div class="hud-row">
                    <span>PARAM (<span id="param_name" style="color:#38bdf8;">Tuning</span>):</span>
                    <span id="param_value" class="hud-val" style="color:#38bdf8;">1.00</span>
                </div>
                <div class="param-bar-bg">
                    <div id="param_bar" class="param-bar-fill"></div>
                </div>
                <div style="font-size: 8px; color: #64748b; margin-top: 5px; text-align: center; letter-spacing: 0.5px;">
                    [RIGHT HAND HEIGHT MODULATES PARAMETER • LEFT FIST ENGAGES AR]
                </div>
            </div>
        </div>

        <div id="analytics_hud">
            <div class="analytics-box">
                <div style="font-family:'Orbitron', sans-serif; font-weight:bold; letter-spacing:1px; margin-bottom:4px;">REAL-TIME HISTOGRAM</div>
                <canvas id="hist_canvas" width="130" height="42" style="background:rgba(0,0,0,0.6); border-radius:4px; border:1px solid rgba(0,255,136,0.3);"></canvas>
                <div style="font-size: 8px; color: #64748b; margin-top: 4px;">256-BIN INTENSITY</div>
            </div>
            <div class="analytics-box">
                <div style="font-family:'Orbitron', sans-serif; font-weight:bold; letter-spacing:1px;">OPERATIONAL KERNEL</div>
                <div id="kernel_grid"></div>
                <button id="clear_ribbons_btn" class="btn-clear" onclick="clearSpatialTrails()">CLEAR 3D TRAILS</button>
            </div>
        </div>

        <div id="hand_cursor"></div>
    </div>

    <!-- Core Graphics & Computer Vision CDNs -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js"></script>

    <script>
    // ==========================================
    // 1. STATE & DIP OPERATION TREE DEFINITION
    // ==========================================
    let activeOp = "Color -> Gray";
    let isFistClosed = false;
    let hoverTimer = null;
    let currentHoverTarget = null;
    let gestureParamFactor = 0.5;

    const dipTree = {
        "UNIT 1: CONVERSIONS": ["Color -> Gray", "Gray -> Binary", "Color -> Binary"],
        "UNIT 2: SPATIAL ENHANCEMENT": ["Negative", "Contrast Stretching", "Thresholding", "Intensity Slicing", "Log Transform", "Gamma Correction", "Smoothing (Blur)", "Median Filter", "Gaussian Filter", "Gradient (Sobel)", "Laplacian", "Histogram Equalization"],
        "UNIT 3: TRANSFORMS": ["DFT Spectrum", "Hadamard Transform", "DCT Compression"],
        "UNIT 4: MORPHOLOGY": ["Dilation", "Erosion", "Opening", "Closing", "Hit-or-Miss", "Boundary Extraction", "Thinning", "Thickening", "Grayscale Morphology"]
    };

    function buildUI() {
        const container = document.getElementById('menu_tree');
        container.innerHTML = '';
        for (let unit in dipTree) {
            let header = document.createElement('div');
            header.className = 'unit-header';
            header.innerText = unit;
            container.appendChild(header);

            dipTree[unit].forEach(op => {
                let btn = document.createElement('div');
                btn.className = 'menu-item' + (op === activeOp ? ' active' : '');
                btn.innerText = op;
                btn.dataset.op = op;
                btn.onclick = () => {
                    activeOp = op;
                    document.getElementById('active_op_label').innerText = activeOp;
                    updateVFXPresetBadge();
                    buildUI();
                };
                container.appendChild(btn);
            });
        }
    }
    buildUI();

    function updateKernelHUD(matrix) {
        const grid = document.getElementById('kernel_grid');
        grid.innerHTML = '';
        if (!matrix || matrix.length !== 9) matrix = [0,0,0, 0,1,0, 0,0,0];
        matrix.forEach(val => {
            let cell = document.createElement('div');
            cell.className = 'kernel-cell';
            cell.innerText = typeof val === 'number' ? val.toFixed(1) : val;
            grid.appendChild(cell);
        });
    }

    function drawLiveHistogram(imgData) {
        const hCanvas = document.getElementById('hist_canvas');
        const hCtx = hCanvas.getContext('2d');
        const d = imgData.data;
        let hist = new Array(256).fill(0);
        for (let i = 0; i < d.length; i += 16) {
            let v = Math.round(0.299 * d[i] + 0.587 * d[i+1] + 0.114 * d[i+2]);
            hist[v]++;
        }
        let maxVal = Math.max(...hist) || 1;
        hCtx.clearRect(0, 0, hCanvas.width, hCanvas.height);
        hCtx.fillStyle = '#00ff88';
        for (let i = 0; i < 130; i++) {
            let bin = Math.floor((i / 130) * 256);
            let h = (hist[bin] / maxVal) * hCanvas.height;
            hCtx.fillRect(i, hCanvas.height - h, 1, h);
        }
    }

    // ==========================================
    // 2. THREE.JS AR SPATIAL CANVAS & VFX ENGINE
    // ==========================================
    let threeScene, threeCamera, threeRenderer;
    let particleSystem, particleGeo, particleMat;
    let particlePositions, particleColors, particleSizes, particleAlphas;
    let particleData = [];
    const MAX_PARTICLES = 1600;

    // 3D Reticle
    let reticleGroup, reticleRingInner, reticleRingOuter, reticleCore;
    let currentPointerWorld = new THREE.Vector3(0, 0, 0);
    let targetPointerWorld = new THREE.Vector3(0, 0, 0);
    let isPointerDetected = false;

    // Spatial Ribbon Air-Painting
    let activeStroke = null;
    let completedStrokes = [];
    const MAX_RIBBON_POINTS = 500;

    function initThreeEngine() {
        const glCanvas = document.getElementById('gl_canvas');
        threeRenderer = new THREE.WebGLRenderer({
            canvas: glCanvas,
            alpha: true,
            antialias: true,
            powerPreference: 'high-performance'
        });
        threeRenderer.setSize(640, 480, false);
        threeRenderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
        threeRenderer.setClearColor(0x000000, 0);

        threeScene = new THREE.Scene();

        // Exact perspective mapping: At z=0, visible viewport is exactly 640 x 480
        const fov = 2 * Math.atan(240 / 500) * (180 / Math.PI);
        threeCamera = new THREE.PerspectiveCamera(fov, 640 / 480, 1, 2000);
        threeCamera.position.set(0, 0, 500);
        threeCamera.lookAt(0, 0, 0);

        // 1. Build Reticle
        reticleGroup = new THREE.Group();
        
        const coreGeo = new THREE.SphereGeometry(3.5, 16, 16);
        const coreMat = new THREE.MeshBasicMaterial({ color: 0x00ff88, wireframe: false });
        reticleCore = new THREE.Mesh(coreGeo, coreMat);
        reticleGroup.add(reticleCore);

        const ringInnerGeo = new THREE.RingGeometry(11, 13, 32);
        const ringInnerMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, side: THREE.DoubleSide, transparent: true, opacity: 0.85 });
        reticleRingInner = new THREE.Mesh(ringInnerGeo, ringInnerMat);
        reticleGroup.add(reticleRingInner);

        const ringOuterGeo = new THREE.RingGeometry(19, 21, 6);
        const ringOuterMat = new THREE.MeshBasicMaterial({ color: 0x00ff88, side: THREE.DoubleSide, transparent: true, opacity: 0.7 });
        reticleRingOuter = new THREE.Mesh(ringOuterGeo, ringOuterMat);
        reticleGroup.add(reticleRingOuter);

        reticleGroup.visible = false;
        threeScene.add(reticleGroup);

        // 2. Build GPU Particle System
        particleGeo = new THREE.BufferGeometry();
        particlePositions = new Float32Array(MAX_PARTICLES * 3);
        particleColors = new Float32Array(MAX_PARTICLES * 3);
        particleSizes = new Float32Array(MAX_PARTICLES);
        particleAlphas = new Float32Array(MAX_PARTICLES);

        for (let i = 0; i < MAX_PARTICLES; i++) {
            particlePositions[i * 3] = 0;
            particlePositions[i * 3 + 1] = 0;
            particlePositions[i * 3 + 2] = -9999;
            particleColors[i * 3] = 0.0;
            particleColors[i * 3 + 1] = 1.0;
            particleColors[i * 3 + 2] = 0.5;
            particleSizes[i] = 0;
            particleAlphas[i] = 0;

            particleData.push({
                active: false,
                vx: 0, vy: 0, vz: 0,
                life: 0, maxLife: 1,
                decay: 0.02,
                sizeBase: 12,
                type: 'plasma'
            });
        }

        particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
        particleGeo.setAttribute('aColor', new THREE.BufferAttribute(particleColors, 3));
        particleGeo.setAttribute('aSize', new THREE.BufferAttribute(particleSizes, 1));
        particleGeo.setAttribute('aAlpha', new THREE.BufferAttribute(particleAlphas, 1));

        // Custom GLSL Shader for Glowing Anti-Aliased VFX Points
        const vfxVertexShader = `
            attribute float aSize;
            attribute vec3 aColor;
            attribute float aAlpha;
            varying vec3 vColor;
            varying float vAlpha;
            void main() {
                vColor = aColor;
                vAlpha = aAlpha;
                vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
                gl_PointSize = aSize * (350.0 / -mvPosition.z);
                gl_Position = projectionMatrix * mvPosition;
            }
        `;

        const vfxFragmentShader = `
            varying vec3 vColor;
            varying float vAlpha;
            void main() {
                float d = distance(gl_PointCoord, vec2(0.5, 0.5));
                if (d > 0.5) discard;
                float glow = pow(1.0 - d * 2.0, 1.6);
                gl_FragColor = vec4(vColor, vAlpha * glow);
            }
        `;

        particleMat = new THREE.ShaderMaterial({
            vertexShader: vfxVertexShader,
            fragmentShader: vfxFragmentShader,
            transparent: true,
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });

        particleSystem = new THREE.Points(particleGeo, particleMat);
        threeScene.add(particleSystem);

        animateThree();
    }

    function emitParticles(count, origin, p, op, isFist) {
        let spawned = 0;
        const speedMultiplier = 1.0 + p * 2.8;
        const blastFactor = isFist ? 2.2 : 1.0;

        let opMode = 'plasma';
        let baseR = 0.0, baseG = 1.0, baseB = 0.5;

        if (op.includes("Sobel") || op.includes("Laplacian")) {
            opMode = 'electric';
            baseR = 0.0; baseG = 0.95; baseB = 1.0;
        } else if (op.includes("Blur") || op.includes("Gaussian") || op.includes("Median")) {
            opMode = 'fog';
            baseR = 0.45; baseG = 0.75; baseB = 1.0;
        } else if (op.includes("Dilation") || op.includes("Erosion") || op.includes("Opening") || op.includes("Closing") || op.includes("Hit-or-Miss") || op.includes("Boundary") || op.includes("Thinning") || op.includes("Thickening") || op.includes("Grayscale Morphology")) {
            opMode = 'matrix';
            baseR = 0.1; baseG = 1.0; baseB = 0.2;
        } else if (op.includes("DFT") || op.includes("Hadamard") || op.includes("DCT")) {
            opMode = 'harmonics';
            baseR = 0.95; baseG = 0.2; baseB = 0.9;
        } else {
            opMode = 'plasma';
            baseR = 0.0; baseG = 1.0; baseB = 0.5;
        }

        for (let i = 0; i < MAX_PARTICLES && spawned < count; i++) {
            let pd = particleData[i];
            if (!pd.active) {
                pd.active = true;
                pd.type = opMode;
                pd.maxLife = Math.max(0.4, 0.7 + Math.random() * 0.8 * (1 + p));
                pd.life = pd.maxLife;
                pd.decay = 0.018 + Math.random() * 0.02;

                let px = origin.x + (Math.random() - 0.5) * 8;
                let py = origin.y + (Math.random() - 0.5) * 8;
                let pz = origin.z + (Math.random() - 0.5) * 8;

                particlePositions[i * 3] = px;
                particlePositions[i * 3 + 1] = py;
                particlePositions[i * 3 + 2] = pz;

                if (opMode === 'electric') {
                    let angle = Math.random() * Math.PI * 2;
                    let spd = (3.5 + Math.random() * 8.0) * speedMultiplier * blastFactor;
                    pd.vx = Math.cos(angle) * spd;
                    pd.vy = Math.sin(angle) * spd;
                    pd.vz = (Math.random() - 0.5) * spd * 1.5;
                    pd.sizeBase = 8 + p * 16;
                    particleColors[i * 3] = Math.random() > 0.4 ? 0.0 : 0.4;
                    particleColors[i * 3 + 1] = 0.9 + Math.random() * 0.1;
                    particleColors[i * 3 + 2] = 1.0;
                } else if (opMode === 'fog') {
                    let angle = Math.random() * Math.PI * 2;
                    let spd = (0.6 + Math.random() * 2.0) * speedMultiplier;
                    pd.vx = Math.cos(angle) * spd;
                    pd.vy = Math.sin(angle) * spd + 0.6;
                    pd.vz = (Math.random() - 0.5) * spd;
                    pd.sizeBase = 20 + p * 35;
                    particleColors[i * 3] = baseR + (Math.random() - 0.5) * 0.2;
                    particleColors[i * 3 + 1] = baseG + (Math.random() - 0.5) * 0.2;
                    particleColors[i * 3 + 2] = baseB;
                } else if (opMode === 'matrix') {
                    const dirs = [-1, 0, 1];
                    let dx = dirs[Math.floor(Math.random() * 3)];
                    let dy = dirs[Math.floor(Math.random() * 3)];
                    let dz = dirs[Math.floor(Math.random() * 3)];
                    let spd = (2.0 + Math.random() * 4.0) * speedMultiplier * blastFactor;
                    pd.vx = dx * spd;
                    pd.vy = dy * spd;
                    pd.vz = dz * spd;
                    pd.sizeBase = 10 + p * 14;
                    particleColors[i * 3] = baseR;
                    particleColors[i * 3 + 1] = baseG;
                    particleColors[i * 3 + 2] = baseB * (Math.random() > 0.5 ? 1.0 : 0.2);
                } else if (opMode === 'harmonics') {
                    let angle = (i % 24) * (Math.PI / 12) + (Date.now() * 0.005);
                    let spd = (2.5 + Math.random() * 4.0) * speedMultiplier;
                    pd.vx = Math.cos(angle) * spd;
                    pd.vy = Math.sin(angle) * spd;
                    pd.vz = Math.sin(angle * 3) * spd;
                    pd.sizeBase = 12 + p * 20;
                    particleColors[i * 3] = baseR;
                    particleColors[i * 3 + 1] = Math.sin(angle) * 0.5 + 0.5;
                    particleColors[i * 3 + 2] = baseB;
                } else {
                    let angle = Math.random() * Math.PI * 2;
                    let spd = (1.5 + Math.random() * 5.0) * speedMultiplier * blastFactor;
                    pd.vx = Math.cos(angle) * spd;
                    pd.vy = Math.sin(angle) * spd + 0.8;
                    pd.vz = (Math.random() - 0.5) * spd;
                    pd.sizeBase = 14 + p * 18;
                    particleColors[i * 3] = Math.random() > 0.3 ? 0.0 : 0.9;
                    particleColors[i * 3 + 1] = 0.8 + Math.random() * 0.2;
                    particleColors[i * 3 + 2] = Math.random() * 0.5;
                }

                particleSizes[i] = pd.sizeBase;
                particleAlphas[i] = 1.0;
                spawned++;
            }
        }
    }

    function updateParticles() {
        for (let i = 0; i < MAX_PARTICLES; i++) {
            let pd = particleData[i];
            if (pd.active) {
                pd.life -= pd.decay;
                if (pd.life <= 0) {
                    pd.active = false;
                    particlePositions[i * 3 + 2] = -9999;
                    particleAlphas[i] = 0;
                    particleSizes[i] = 0;
                    continue;
                }

                if (pd.type === 'electric') {
                    pd.vx += (Math.random() - 0.5) * 3.5;
                    pd.vy += (Math.random() - 0.5) * 3.5;
                }

                particlePositions[i * 3] += pd.vx;
                particlePositions[i * 3 + 1] += pd.vy;
                particlePositions[i * 3 + 2] += pd.vz;

                let progress = pd.life / pd.maxLife;
                if (pd.type === 'fog') {
                    particleSizes[i] = pd.sizeBase * (1.0 + (1.0 - progress) * 1.5);
                    particleAlphas[i] = progress * 0.65;
                } else {
                    particleSizes[i] = pd.sizeBase * progress;
                    particleAlphas[i] = Math.min(1.0, progress * 1.4);
                }
            }
        }

        particleGeo.attributes.position.needsUpdate = true;
        particleGeo.attributes.aColor.needsUpdate = true;
        particleGeo.attributes.aSize.needsUpdate = true;
        particleGeo.attributes.aAlpha.needsUpdate = true;
    }

    // ==========================================
    // 3. PERSISTENT 3D SPATIAL RIBBON BRUSH
    // ==========================================
    function createRibbonStroke() {
        const ribbonGeo = new THREE.BufferGeometry();
        const posArray = new Float32Array(MAX_RIBBON_POINTS * 2 * 3);
        const colArray = new Float32Array(MAX_RIBBON_POINTS * 2 * 3);
        const idxArray = new Uint16Array((MAX_RIBBON_POINTS - 1) * 6);

        ribbonGeo.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
        ribbonGeo.setAttribute('color', new THREE.BufferAttribute(colArray, 3));

        let idxPtr = 0;
        for (let i = 0; i < MAX_RIBBON_POINTS - 1; i++) {
            let v1 = i * 2;
            let v2 = i * 2 + 1;
            let v3 = (i + 1) * 2;
            let v4 = (i + 1) * 2 + 1;

            idxArray[idxPtr++] = v1;
            idxArray[idxPtr++] = v2;
            idxArray[idxPtr++] = v3;

            idxArray[idxPtr++] = v2;
            idxArray[idxPtr++] = v4;
            idxArray[idxPtr++] = v3;
        }
        ribbonGeo.setIndex(new THREE.BufferAttribute(idxArray, 1));
        ribbonGeo.setDrawRange(0, 0);

        const ribbonMat = new THREE.MeshBasicMaterial({
            vertexColors: true,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.85,
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });

        const mesh = new THREE.Mesh(ribbonGeo, ribbonMat);
        threeScene.add(mesh);

        return {
            mesh: mesh,
            geo: ribbonGeo,
            posAttr: ribbonGeo.attributes.position,
            colAttr: ribbonGeo.attributes.color,
            points: [],
            vertexCount: 0
        };
    }

    function addPointToRibbon(stroke, pos, p, op) {
        if (stroke.vertexCount >= MAX_RIBBON_POINTS) return;

        const points = stroke.points;
        if (points.length > 0) {
            let lastP = points[points.length - 1];
            if (pos.distanceTo(lastP) < 3.5) return;
        }

        points.push(pos.clone());

        let idx = stroke.vertexCount;
        let halfWidth = 5.0 + p * 16.0;

        let normal = new THREE.Vector3(0, 1, 0);
        if (points.length >= 2) {
            let prev = points[points.length - 2];
            let dir = new THREE.Vector3().subVectors(pos, prev).normalize();
            let view = new THREE.Vector3(0, 0, 1);
            normal.crossVectors(dir, view).normalize();
        }

        let pLeft = new THREE.Vector3().addVectors(pos, normal.clone().multiplyScalar(halfWidth));
        let pRight = new THREE.Vector3().subVectors(pos, normal.clone().multiplyScalar(halfWidth));

        let posArr = stroke.posAttr.array;
        let colArr = stroke.colAttr.array;

        posArr[idx * 6] = pLeft.x;
        posArr[idx * 6 + 1] = pLeft.y;
        posArr[idx * 6 + 2] = pLeft.z;

        posArr[idx * 6 + 3] = pRight.x;
        posArr[idx * 6 + 4] = pRight.y;
        posArr[idx * 6 + 5] = pRight.z;

        let r = 0.0, g = 1.0, b = 0.5;
        if (op.includes("Sobel") || op.includes("Laplacian")) { r = 0.0; g = 0.9; b = 1.0; }
        else if (op.includes("Blur") || op.includes("Gaussian")) { r = 0.3; g = 0.6; b = 1.0; }
        else if (op.includes("DFT") || op.includes("Hadamard") || op.includes("DCT")) { r = 0.95; g = 0.1; b = 0.8; }
        else if (op.includes("Dilation") || op.includes("Morphology")) { r = 1.0; g = 0.8; b = 0.0; }

        colArr[idx * 6] = r; colArr[idx * 6 + 1] = g; colArr[idx * 6 + 2] = b;
        colArr[idx * 6 + 3] = r * 0.7; colArr[idx * 6 + 4] = g * 0.7; colArr[idx * 6 + 5] = b * 0.7;

        stroke.vertexCount++;
        stroke.posAttr.needsUpdate = true;
        stroke.colAttr.needsUpdate = true;

        if (stroke.vertexCount > 1) {
            stroke.geo.setDrawRange(0, (stroke.vertexCount - 1) * 6);
        }
    }

    window.clearSpatialTrails = function() {
        if (activeStroke) {
            threeScene.remove(activeStroke.mesh);
            activeStroke.geo.dispose();
            activeStroke = null;
        }
        completedStrokes.forEach(s => {
            threeScene.remove(s.mesh);
            s.geo.dispose();
        });
        completedStrokes = [];
    };

    function updateVFXPresetBadge() {
        const badge = document.getElementById('vfx_preset_label');
        if (activeOp.includes("Sobel") || activeOp.includes("Laplacian")) {
            badge.innerText = "Electric Arc";
            badge.className = "hud-badge badge-cyan";
        } else if (activeOp.includes("Blur") || activeOp.includes("Gaussian") || activeOp.includes("Median")) {
            badge.innerText = "Ambient Ethereal Fog";
            badge.className = "hud-badge badge-active";
        } else if (activeOp.includes("DFT") || activeOp.includes("Hadamard") || activeOp.includes("DCT")) {
            badge.innerText = "Harmonic Resonance";
            badge.className = "hud-badge badge-cyan";
        } else if (activeOp.includes("Dilation") || activeOp.includes("Morphology") || activeOp.includes("Erosion")) {
            badge.innerText = "Binary Voxel Grid";
            badge.className = "hud-badge badge-active";
        } else {
            badge.innerText = "Chromatic Plasma";
            badge.className = "hud-badge badge-cyan";
        }
    }

    function animateThree() {
        requestAnimationFrame(animateThree);

        if (isPointerDetected) {
            currentPointerWorld.lerp(targetPointerWorld, 0.35);
            reticleGroup.position.copy(currentPointerWorld);
            reticleGroup.visible = true;

            reticleRingInner.rotation.z += 0.04;
            reticleRingOuter.rotation.z -= 0.02;

            const time = Date.now() * 0.004;
            if (isFistClosed) {
                reticleCore.material.color.setHex(0x00ff88);
                reticleRingOuter.material.color.setHex(0x00ff88);
                let pulse = 1.25 + Math.sin(time * 3) * 0.15;
                reticleGroup.scale.set(pulse, pulse, pulse);

                // AIR-PAINTING: Project persistent 3D ribbon in world space
                if (!activeStroke) {
                    activeStroke = createRibbonStroke();
                }
                addPointToRibbon(activeStroke, currentPointerWorld, gestureParamFactor, activeOp);
                document.getElementById('paint_state_label').innerText = "DRAWING 3D TRAIL";
                document.getElementById('paint_state_label').className = "hud-badge badge-active";

                // Emit dynamic particles in turbo mode
                emitParticles(16, currentPointerWorld, gestureParamFactor, activeOp, true);
            } else {
                reticleCore.material.color.setHex(0x38bdf8);
                reticleRingOuter.material.color.setHex(0x38bdf8);
                let calm = 1.0 + Math.sin(time) * 0.05;
                reticleGroup.scale.set(calm, calm, calm);

                if (activeStroke) {
                    completedStrokes.push(activeStroke);
                    activeStroke = null;
                }
                document.getElementById('paint_state_label').innerText = "Standby";
                document.getElementById('paint_state_label').className = "hud-badge badge-cyan";

                // Gentle ambient particle emission
                emitParticles(3, currentPointerWorld, gestureParamFactor, activeOp, false);
            }
        } else {
            reticleGroup.visible = false;
            if (activeStroke) {
                completedStrokes.push(activeStroke);
                activeStroke = null;
            }
        }

        updateParticles();
        threeRenderer.render(threeScene, threeCamera);
    }

    // ==========================================
    // 4. MAIN DIP INITIALIZATION & HAND TRACKING
    // ==========================================
    async function initSystem() {
        const video = document.getElementById('video_feed');
        const canvas = document.getElementById('output_canvas');
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        const cursor = document.getElementById('hand_cursor');
        const sidebar = document.getElementById('sidebar');
        const scrollUpInd = document.getElementById('scroll_top_ind');
        const scrollDownInd = document.getElementById('scroll_bottom_ind');
        const appContainer = document.getElementById('dip_app');

        canvas.width = 640;
        canvas.height = 480;

        initThreeEngine();
        updateVFXPresetBadge();

        let stream = null;
        try {
            if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
                video.srcObject = stream;
                await video.play();
            }
        } catch (err) {
            console.warn("Camera stream unavailable. Running procedural visualizer.", err);
        }

        const hands = new Hands({ locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}` });
        hands.setOptions({ maxNumHands: 2, modelComplexity: 0, minDetectionConfidence: 0.5, minTrackingConfidence: 0.5 });

        hands.onResults((results) => {
            const appRect = appContainer.getBoundingClientRect();
            ctx.save();
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

            isFistClosed = false;
            let cursorScreenPos = null;
            isPointerDetected = false;

            if (results.multiHandLandmarks && results.multiHandedness) {
                for (let i = 0; i < results.multiHandLandmarks.length; i++) {
                    let label = results.multiHandedness[i].label;
                    let landmarks = results.multiHandLandmarks[i];

                    // Left hand fist triggers active state & spatial painting
                    if (label === 'Left') {
                        let wrist = landmarks[0];
                        let tips = [8, 12, 16, 20];
                        let closed = 0;
                        tips.forEach(t => {
                            if (Math.hypot(landmarks[t].x - wrist.x, landmarks[t].y - wrist.y) < 0.25) closed++;
                        });
                        if (closed >= 3) isFistClosed = true;
                    }

                    // Right hand controls parameter modulation, 3D reticle & air cursor
                    if (label === 'Right') {
                        let indexTip = landmarks[8];
                        cursorScreenPos = {
                            x: (1 - indexTip.x) * appRect.width,
                            y: indexTip.y * appRect.height
                        };
                        gestureParamFactor = Math.max(0, Math.min(1, 1 - indexTip.y));

                        let rawX = indexTip.x * 640;
                        let rawY = indexTip.y * 480;
                        let depthZ = (landmarks[8].z || 0) * -380;

                        targetPointerWorld.set(
                            rawX - 320,
                            -(rawY - 240),
                            depthZ
                        );
                        isPointerDetected = true;
                    }
                }
            }

            let frame = ctx.getImageData(0, 0, canvas.width, canvas.height);

            // Execute Comprehensive DIP Engine
            applyDIPEngine(frame, activeOp, ctx, canvas, gestureParamFactor, isFistClosed);

            drawLiveHistogram(frame);
            ctx.restore();

            const trigLabel = document.getElementById('trigger_label');
            if (isFistClosed) {
                trigLabel.innerText = "ACTIVE (Fist Engaged)";
                trigLabel.style.color = "#00ff88";
                cursor.classList.add('fist-active');
            } else {
                trigLabel.innerText = "PASS-THROUGH (Open Hand)";
                trigLabel.style.color = "#ef4444";
                cursor.classList.remove('fist-active');
            }

            document.getElementById('param_bar').style.width = Math.round(gestureParamFactor * 100) + '%';

            if (cursorScreenPos) {
                cursor.style.display = 'block';
                cursor.style.left = cursorScreenPos.x + 'px';
                cursor.style.top = cursorScreenPos.y + 'px';

                if (cursorScreenPos.x <= 300) {
                    const scrollZone = 120;
                    if (cursorScreenPos.y < scrollZone) {
                        sidebar.scrollTop -= Math.max(2, Math.round((scrollZone - cursorScreenPos.y) / 6));
                        scrollUpInd.style.opacity = '1';
                    } else scrollUpInd.style.opacity = '0';

                    if (cursorScreenPos.y > (appRect.height - scrollZone)) {
                        sidebar.scrollTop += Math.max(2, Math.round((cursorScreenPos.y - (appRect.height - scrollZone)) / 6));
                        scrollDownInd.style.opacity = '1';
                    } else scrollDownInd.style.opacity = '0';

                    let hit = document.elementFromPoint(appRect.left + cursorScreenPos.x, appRect.top + cursorScreenPos.y);
                    if (hit && hit.classList.contains('menu-item')) {
                        if (currentHoverTarget !== hit) {
                            currentHoverTarget = hit;
                            clearTimeout(hoverTimer);
                            hoverTimer = setTimeout(() => {
                                activeOp = currentHoverTarget.dataset.op;
                                document.getElementById('active_op_label').innerText = activeOp;
                                updateVFXPresetBadge();
                                buildUI();
                            }, 400);
                        }
                    } else { currentHoverTarget = null; clearTimeout(hoverTimer); }
                } else {
                    scrollUpInd.style.opacity = '0';
                    scrollDownInd.style.opacity = '0';
                    currentHoverTarget = null;
                    clearTimeout(hoverTimer);
                }
            } else {
                cursor.style.display = 'none';
                scrollUpInd.style.opacity = '0';
                scrollDownInd.style.opacity = '0';
            }
        });

        if (stream) {
            const cam = new Camera(video, {
                onFrame: async () => { await hands.send({ image: video }); },
                width: 640, height: 480
            });
            cam.start();
        } else {
            let simTime = 0;
            const simCanvas = document.createElement('canvas');
            simCanvas.width = 640; simCanvas.height = 480;
            const simCtx = simCanvas.getContext('2d');

            function runProceduralSimulation() {
                simTime += 0.03;
                simCtx.fillStyle = '#061325';
                simCtx.fillRect(0, 0, 640, 480);

                for (let i = 0; i < 6; i++) {
                    let cx = 320 + Math.sin(simTime + i) * 160;
                    let cy = 240 + Math.cos(simTime * 0.8 + i) * 110;
                    let grad = simCtx.createRadialGradient(cx, cy, 10, cx, cy, 90);
                    grad.addColorStop(0, i % 2 === 0 ? 'rgba(0, 255, 136, 0.8)' : 'rgba(56, 189, 248, 0.8)');
                    grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
                    simCtx.fillStyle = grad;
                    simCtx.beginPath();
                    simCtx.arc(cx, cy, 90, 0, Math.PI * 2);
                    simCtx.fill();
                }

                ctx.drawImage(simCanvas, 0, 0);
                let frame = ctx.getImageData(0, 0, 640, 480);
                applyDIPEngine(frame, activeOp, ctx, canvas, gestureParamFactor, true);
                drawLiveHistogram(frame);

                let simPx = (Math.sin(simTime * 0.7) * 0.35 + 0.5) * 640;
                let simPy = (Math.cos(simTime * 0.9) * 0.35 + 0.5) * 480;
                targetPointerWorld.set(simPx - 320, -(simPy - 240), 0);
                isPointerDetected = true;
                isFistClosed = (Math.sin(simTime * 0.5) > -0.2);

                requestAnimationFrame(runProceduralSimulation);
            }
            runProceduralSimulation();
        }
    }

    // ==========================================
    // 5. COMPREHENSIVE DIP ENGINE (UNITS 1 - 4)
    // ==========================================
    function applyDIPEngine(imgData, op, ctx, canvas, p, isActive) {
        let d = imgData.data;
        let w = imgData.width;
        let h = imgData.height;
        let len = d.length;
        let k = [0,0,0, 0,1,0, 0,0,0];
        let pName = document.getElementById('param_name');
        let pVal = document.getElementById('param_value');

        // SPECIAL CASE: Gray -> Binary
        if (op === "Gray -> Binary") {
            let tVal = Math.round(p * 255);
            pName.innerText = "Cutoff T"; pVal.innerText = tVal;

            for (let i = 0; i < len; i += 4) {
                let v = 0.299 * d[i] + 0.587 * d[i+1] + 0.114 * d[i+2];
                let finalVal = isActive ? (v > tVal ? 255 : 0) : v;
                d[i] = d[i+1] = d[i+2] = finalVal;
            }
            ctx.putImageData(imgData, 0, 0);
            updateKernelHUD(k);
            return;
        }

        // Standard Pass-Through for other operations when fist is open
        if (!isActive) {
            updateKernelHUD([0,0,0, 0,1,0, 0,0,0]);
            return;
        }

        switch(op) {
            // UNIT 1: CONVERSIONS
            case "Color -> Gray":
                pName.innerText = "Gray Alpha"; pVal.innerText = p.toFixed(2);
                for (let i = 0; i < len; i += 4) {
                    let v = 0.299 * d[i] + 0.587 * d[i+1] + 0.114 * d[i+2];
                    d[i] = d[i]*(1-p) + v*p;
                    d[i+1] = d[i+1]*(1-p) + v*p;
                    d[i+2] = d[i+2]*(1-p) + v*p;
                }
                ctx.putImageData(imgData, 0, 0); break;

            case "Color -> Binary":
            case "Thresholding":
                let tVal = Math.round(p * 255);
                pName.innerText = "Cutoff T"; pVal.innerText = tVal;
                for (let i = 0; i < len; i += 4) {
                    let v = 0.299 * d[i] + 0.587 * d[i+1] + 0.114 * d[i+2];
                    let res = v > tVal ? 255 : 0;
                    d[i] = d[i+1] = d[i+2] = res;
                }
                ctx.putImageData(imgData, 0, 0); break;

            // UNIT 2: SPATIAL ENHANCEMENT
            case "Negative":
                pName.innerText = "Inversion"; pVal.innerText = p.toFixed(2);
                for (let i = 0; i < len; i += 4) {
                    d[i] = d[i]*(1-p) + (255 - d[i])*p;
                    d[i+1] = d[i+1]*(1-p) + (255 - d[i+1])*p;
                    d[i+2] = d[i+2]*(1-p) + (255 - d[i+2])*p;
                }
                ctx.putImageData(imgData, 0, 0); break;

            case "Contrast Stretching":
                let gain = 1.0 + p * 3.0;
                pName.innerText = "Slope (A)"; pVal.innerText = gain.toFixed(2);
                let minV = 255, maxV = 0;
                for (let i = 0; i < len; i += 4) {
                    let v = 0.299 * d[i] + 0.587 * d[i+1] + 0.114 * d[i+2];
                    if (v < minV) minV = v; if (v > maxV) maxV = v;
                }
                for (let i = 0; i < len; i += 4) {
                    for(let c=0; c<3; c++) d[i+c] = Math.min(255, Math.max(0, ((d[i+c] - minV) / (maxV - minV || 1)) * 255 * gain));
                }
                ctx.putImageData(imgData, 0, 0); break;

            case "Intensity Slicing":
                let minS = Math.round(p * 150);
                pName.innerText = "Band"; pVal.innerText = minS + "-" + (minS+80);
                for (let i = 0; i < len; i += 4) {
                    let v = 0.299 * d[i] + 0.587 * d[i+1] + 0.114 * d[i+2];
                    if (v >= minS && v <= minS + 80) { d[i] = 0; d[i+1] = 255; d[i+2] = 0; }
                }
                ctx.putImageData(imgData, 0, 0); break;

            case "Log Transform":
                let cLog = 255 / Math.log(256);
                pName.innerText = "Log C"; pVal.innerText = p.toFixed(2);
                for (let i = 0; i < len; i += 4) {
                    d[i] = cLog * Math.log(1 + d[i]*p);
                    d[i+1] = cLog * Math.log(1 + d[i+1]*p);
                    d[i+2] = cLog * Math.log(1 + d[i+2]*p);
                }
                ctx.putImageData(imgData, 0, 0); break;

            case "Gamma Correction":
                let gamma = 0.1 + p * 2.5;
                pName.innerText = "Gamma (γ)"; pVal.innerText = gamma.toFixed(2);
                for (let i = 0; i < len; i += 4) {
                    d[i] = 255 * Math.pow(d[i]/255, gamma);
                    d[i+1] = 255 * Math.pow(d[i+1]/255, gamma);
                    d[i+2] = 255 * Math.pow(d[i+2]/255, gamma);
                }
                ctx.putImageData(imgData, 0, 0); break;

            case "Smoothing (Blur)":
            case "Gaussian Filter":
                let px = Math.round(1 + p * 16);
                pName.innerText = "Kernel Radius"; pVal.innerText = px + "px";
                k = [0.1, 0.1, 0.1, 0.1, 0.2, 0.1, 0.1, 0.1, 0.1];
                ctx.save();
                ctx.filter = `blur(${px}px)`;
                ctx.drawImage(document.getElementById('video_feed'), 0, 0, canvas.width, canvas.height);
                ctx.restore(); break;

            case "Median Filter":
                pName.innerText = "Neighborhood"; pVal.innerText = "3x3";
                let srcM = new Uint8ClampedArray(d);
                for (let y = 1; y < h - 1; y += 2) {
                    for (let x = 1; x < w - 1; x += 2) {
                        let idx = (y * w + x) * 4;
                        let vals = [srcM[idx], srcM[idx-4], srcM[idx+4], srcM[idx-w*4], srcM[idx+w*4]];
                        vals.sort((a,b)=>a-b);
                        d[idx] = d[idx+1] = d[idx+2] = vals[2];
                    }
                }
                ctx.putImageData(imgData, 0, 0); break;

            case "Gradient (Sobel)":
            case "Laplacian":
                if (op.includes("Sobel")) k = [-1, 0, 1, -2, 0, 2, -1, 0, 1];
                else k = [0, -1, 0, -1, 4, -1, 0, -1, 0];
                pName.innerText = "Gain"; pVal.innerText = (p*3).toFixed(1);
                let srcG = new Uint8Array(len);
                for (let i = 0; i < len; i += 4) srcG[i] = 0.299 * d[i] + 0.587 * d[i+1] + 0.114 * d[i+2];
                for (let y = 1; y < h - 1; y++) {
                    for (let x = 1; x < w - 1; x++) {
                        let i = (y * w + x) * 4;
                        let gx = -srcG[((y-1)*w+(x-1))*4] + srcG[((y-1)*w+(x+1))*4] - 2*srcG[(y*w+(x-1))*4] + 2*srcG[(y*w+(x+1))*4] - srcG[((y+1)*w+(x-1))*4] + srcG[((y+1)*w+(x+1))*4];
                        let gy = srcG[((y-1)*w+(x-1))*4] + 2*srcG[((y-1)*w+x)*4] + srcG[((y-1)*w+(x+1))*4] - srcG[((y+1)*w+(x-1))*4] - 2*srcG[(y*w+x)*4] - srcG[((y+1)*w+(x+1))*4];
                        d[i] = d[i+1] = d[i+2] = Math.min(255, Math.sqrt(gx*gx + gy*gy) * (p * 2.5));
                    }
                }
                ctx.putImageData(imgData, 0, 0); break;

            case "Histogram Equalization":
                pName.innerText = "Equalize Mix"; pVal.innerText = p.toFixed(2);
                let hist = new Array(256).fill(0);
                for (let i = 0; i < len; i += 4) hist[Math.round(0.299 * d[i] + 0.587 * d[i+1] + 0.114 * d[i+2])]++;
                let cdf = new Array(256).fill(0); cdf[0] = hist[0];
                for (let i = 1; i < 256; i++) cdf[i] = cdf[i-1] + hist[i];
                let cdfMin = cdf.find(x => x > 0) || 1;
                for (let i = 0; i < len; i += 4) {
                    let v = Math.round(0.299 * d[i] + 0.587 * d[i+1] + 0.114 * d[i+2]);
                    let eq = Math.round(((cdf[v] - cdfMin) / (w*h - cdfMin)) * 255);
                    d[i] = d[i+1] = d[i+2] = v*(1-p) + eq*p;
                }
                ctx.putImageData(imgData, 0, 0); break;

            // UNIT 3: TRANSFORMS
            case "DFT Spectrum":
            case "Hadamard Transform":
            case "DCT Compression":
                let freqCut = Math.round(1 + p * 7);
                pName.innerText = op.includes("DCT") ? "Quantize" : "Frequency"; pVal.innerText = freqCut;
                k = [1,0,1, 0,8,0, 1,0,1];
                for (let y = 0; y < h; y += 8) {
                    for (let x = 0; x < w; x += 8) {
                        for (let by = 0; by < 8; by++) {
                            for (let bx = 0; bx < 8; bx++) {
                                let i = ((y + by) * w + (x + bx)) * 4;
                                let spectrum = (Math.sin(bx * freqCut) * Math.cos(by * freqCut) + 1) * 127;
                                if (op.includes("DCT") && bx >= freqCut) d[i] = d[i+1] = d[i+2] = 0;
                                else if (op.includes("DFT")) d[i] = d[i+1] = d[i+2] = spectrum;
                                else d[i] = d[i+1] = d[i+2] = (bx ^ by) * 32;
                            }
                        }
                    }
                }
                ctx.putImageData(imgData, 0, 0); break;

            // UNIT 4: MORPHOLOGY
            case "Dilation":
            case "Erosion":
            case "Opening":
            case "Closing":
            case "Hit-or-Miss":
            case "Boundary Extraction":
            case "Thinning":
            case "Thickening":
            case "Grayscale Morphology":
                let iters = Math.round(1 + p * 3);
                pName.innerText = "Structuring Radius"; pVal.innerText = iters;
                k = [1,1,1, 1,1,1, 1,1,1];
                let bin = new Uint8Array(len);
                for (let i = 0; i < len; i += 4) bin[i] = (0.299*d[i] + 0.587*d[i+1] + 0.114*d[i+2]) > 120 ? 255 : 0;
                let isDilate = op.includes("Dilation") || op.includes("Closing") || op.includes("Thickening");
                for (let y = 2; y < h - 2; y += 2) {
                    for (let x = 2; x < w - 2; x += 2) {
                        let i = (y * w + x) * 4;
                        let val = bin[i];
                        if (isDilate) val = bin[i] || bin[i-4*iters] || bin[i+4*iters] || bin[i-w*4*iters] || bin[i+w*4*iters] ? 255 : 0;
                        else val = bin[i] && bin[i-4*iters] && bin[i+4*iters] && bin[i-w*4*iters] && bin[i+w*4*iters] ? 255 : 0;
                        if (op.includes("Boundary")) val = Math.max(0, bin[i] - val);
                        d[i] = d[i+1] = d[i+2] = val;
                    }
                }
                ctx.putImageData(imgData, 0, 0); break;
        }

        updateKernelHUD(k);
    }

    setTimeout(initSystem, 600);
    </script>
    """
    display(HTML(html_code))

launch_dip_engine_v5()
