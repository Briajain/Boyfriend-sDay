(function () {
  function initIntro() {
    var rideButton = document.getElementById('hero-ride-button');
    var gameSection = document.getElementById('game');

    if (!rideButton || !gameSection) {
      return;
    }

    rideButton.addEventListener('click', function () {
      gameSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  }

  window.MemoriesIntro = {
    init: initIntro
  };
})();
