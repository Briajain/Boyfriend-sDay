(function () {
  var WISH_PHRASES = [
    'Out of all the roads in this world, I’m glad ours crossed.',
    'You make my ordinary days feel extraordinary.',
    'My favourite place will always be beside you.',
    'If the stars could write, they would spell your name.',
    'One lifetime sounds beautiful, as long as it has you in it.',
    'You are my calm and my adventure, all at once.',
    'Every wish I make already has you in it.',
    'Loving you is the easiest thing I have ever done.',
    'Your laugh is my favourite sound in the universe.',
    'Wherever you are is where my heart lives.',
    'Thank you for being exactly who you are.',
    'You and me, on every road, in every lifetime.',
    'I would choose you again, and again, and again.',
    'You make the whole world feel like home.',
    'My heart knew you before I ever met you.',
    'Here’s to every mile we haven’t ridden yet.'
  ];

  var intervals = [];

  function randomPhrase() {
    return WISH_PHRASES[Math.floor(Math.random() * WISH_PHRASES.length)];
  }

  function clearIntervals() {
    intervals.forEach(function (id) {
      window.clearInterval(id);
    });
    intervals = [];
  }

  function prefersReducedMotion() {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }

  function createStars(container) {
    var total = window.matchMedia('(max-width: 768px)').matches ? 52 : 104;
    for (var i = 0; i < total; i++) {
      var star = document.createElement('span');
      star.className = 'meteor-star';
      star.style.left = (Math.random() * 100).toFixed(2) + '%';
      star.style.top = (Math.random() * 100).toFixed(2) + '%';
      star.style.opacity = (0.18 + Math.random() * 0.62).toFixed(2);
      star.style.animationDelay = (Math.random() * 6).toFixed(2) + 's';
      container.appendChild(star);
    }
  }

  function countActive(container, selector) {
    return container.querySelectorAll(selector).length;
  }

  function createWishPhrase(container) {
    var limit = window.matchMedia('(max-width: 768px)').matches ? 3 : 4;
    if (countActive(container, '.meteor-phrase') >= limit) {
      return;
    }

    var item = document.createElement('span');
    item.className = 'meteor-phrase';
    item.textContent = randomPhrase();
    item.style.left = (40 + Math.random() * 46).toFixed(2) + '%';
    item.style.top = (-12 + Math.random() * 30).toFixed(2) + '%';
    item.style.animationDuration = (22 + Math.random() * 12).toFixed(2) + 's';
    item.style.fontSize = (14 + Math.random() * 10).toFixed(0) + 'px';
    item.style.opacity = (0.6 + Math.random() * 0.34).toFixed(2);
    container.appendChild(item);

    item.addEventListener('animationend', function () {
      item.remove();
    });
  }

  function createShootingStar(container) {
    if (countActive(container, '.shooting-star') >= 2) {
      return;
    }

    var star = document.createElement('span');
    star.className = 'shooting-star';
    star.style.left = (55 + Math.random() * 44).toFixed(2) + '%';
    star.style.top = (Math.random() * 45).toFixed(2) + '%';
    container.appendChild(star);

    star.addEventListener('animationend', function () {
      star.remove();
    });
  }

  function initMeteors() {
    var scene = document.getElementById('meteors-scene');
    if (!scene) {
      return;
    }

    clearIntervals();
    scene.innerHTML = '';

    createStars(scene);

    if (prefersReducedMotion()) {
      // A calm, static sky with a few gentle wishes — no streaking.
      for (var index = 0; index < 3; index++) {
        var phrase = document.createElement('span');
        phrase.className = 'meteor-phrase';
        phrase.textContent = randomPhrase();
        phrase.style.left = (12 + index * 30).toFixed(2) + '%';
        phrase.style.top = (18 + (index % 2) * 34).toFixed(2) + '%';
        phrase.style.fontSize = '16px';
        phrase.style.opacity = '0.85';
        scene.appendChild(phrase);
      }
      return;
    }

    intervals.push(window.setInterval(function () {
      createWishPhrase(scene);
    }, 4200));

    intervals.push(window.setInterval(function () {
      if (Math.random() > 0.4) {
        createShootingStar(scene);
      }
    }, 6400));

    for (var index = 0; index < 2; index++) {
      window.setTimeout(function () {
        createWishPhrase(scene);
      }, index * 1600);
    }
  }

  window.MemoriesMeteors = {
    init: initMeteors
  };
})();
