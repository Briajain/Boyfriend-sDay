(function () {
  var TARGET_DISTANCE = 1000; // metres
  var PX_PER_METRE = 16;
  var LANE_COUNT = 3;
  var MAX_DT = 50; // ms — clamp frame steps (tab switches etc.)

  var canvas = null;
  var ctx = null;
  var shell = null;

  var overlays = {};
  var hud = {};

  var state = 'idle'; // idle | running | complete
  var counterUnlocked = false;

  var lastFrameTime = 0;
  var rafId = null;

  var player = {
    lane: 1,
    x: 0,
    targetX: 0
  };

  var world = {
    speed: 0,
    distance: 0,
    roadOffset: 0,
    spawnTimer: 0,
    obstacles: [],
    bumpTimer: 0,
    bumpFactor: 1,
    bumpCount: 0,
    bumpParticles: [],
    floaters: []
  };

  var stars = [];
  var trees = [];

  function randomBetween(min, max) {
    return min + Math.random() * (max - min);
  }

  function laneX(lane, width) {
    var roadLeft = width * 0.16;
    var roadRight = width * 0.84;
    var laneWidth = (roadRight - roadLeft) / LANE_COUNT;
    return roadLeft + laneWidth * (lane + 0.5);
  }

  function roadTop(height) {
    return height * 0.46;
  }

  function setupScenery(width, height) {
    stars = [];
    var totalStars = Math.round(width / 9);
    for (var index = 0; index < totalStars; index++) {
      stars.push({
        x: Math.random() * width,
        y: Math.random() * roadTop(height) * 0.92,
        r: randomBetween(0.5, 1.6),
        phase: Math.random() * Math.PI * 2,
        speed: randomBetween(0.6, 2.2)
      });
    }

    trees = [];
    var totalTrees = 16;
    for (var treeIndex = 0; treeIndex < totalTrees; treeIndex++) {
      trees.push({
        side: treeIndex % 2 === 0 ? 'left' : 'right',
        offset: (treeIndex / totalTrees) * height * 1.6,
        scale: randomBetween(0.75, 1.25)
      });
    }
  }

  function resizeCanvas() {
    if (!canvas || !ctx) {
      return;
    }

    var cssWidth = canvas.clientWidth || canvas.parentElement.clientWidth;
    var cssHeight = canvas.clientHeight || 380;
    var dpr = window.devicePixelRatio || 1;

    canvas.width = Math.round(cssWidth * dpr);
    canvas.height = Math.round(cssHeight * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    player.targetX = laneX(player.lane, cssWidth);
    if (state === 'idle') {
      player.x = player.targetX;
    }

    setupScenery(cssWidth, cssHeight);
  }

  function resetGame() {
    world.speed = 300;
    world.distance = 0;
    world.roadOffset = 0;
    world.spawnTimer = 1.2;
    world.obstacles = [];
    world.bumpTimer = 0;
    world.bumpFactor = 1;
    world.bumpCount = 0;
    world.bumpParticles = [];
    world.floaters = [];
    player.lane = 1;
    player.x = laneX(1, canvas.clientWidth);
    player.targetX = player.x;
  }

  function setOverlay(name) {
    Object.keys(overlays).forEach(function (key) {
      if (overlays[key]) {
        overlays[key].hidden = key !== name;
      }
    });
  }

  function startRide() {
    if (!canvas) {
      return;
    }
    resizeCanvas();
    resetGame();
    state = 'running';
    setOverlay('none');
    lastFrameTime = window.performance.now();
    if (rafId === null) {
      rafId = window.requestAnimationFrame(loop);
    }
  }

  function bump(obstacleX, obstacleY) {
    // Friendly collision: a little shake, sparks and a heart — never a loss.
    world.bumpTimer = 0.45;
    world.bumpFactor = 0.55;
    world.bumpCount += 1;

    for (var index = 0; index < 12; index++) {
      world.bumpParticles.push({
        x: obstacleX,
        y: obstacleY,
        vx: randomBetween(-90, 90),
        vy: randomBetween(-150, -30),
        age: 0,
        life: randomBetween(0.5, 0.9),
        r: randomBetween(1.5, 3.5)
      });
    }

    world.floaters.push({
      x: obstacleX,
      y: obstacleY - 34,
      age: 0,
      life: 1.1,
      text: '💙'
    });
  }

  function completeRide() {
    state = 'complete';
    setOverlay('complete');
    unlockCounter();
  }

  function unlockCounter() {
    if (counterUnlocked) {
      return;
    }
    counterUnlocked = true;

    var counterSection = document.getElementById('counter');
    var navLink = document.getElementById('nav-counter-link');

    if (counterSection) {
      counterSection.classList.remove('is-locked');
    }
    if (navLink) {
      navLink.removeAttribute('data-locked');
    }
    var hint = document.getElementById('nav-counter-hint');
    if (hint) {
      hint.textContent = '';
    }
  }

  function isCounterUnlocked() {
    return counterUnlocked;
  }

  function spawnObstacle() {
    var lane = Math.floor(Math.random() * LANE_COUNT);
    var type = Math.random() > 0.42 ? 'cone' : 'barrier';

    world.obstacles.push({
      lane: lane,
      type: type,
      y: roadTop(canvas.clientHeight) - 30,
      passed: false
    });
  }

  function update(dt) {
    // Speed ramps up gently across the ride; a bump briefly slows it.
    var progress = Math.min(1, world.distance / TARGET_DISTANCE);

    if (world.bumpTimer > 0) {
      world.bumpTimer = Math.max(0, world.bumpTimer - dt / 1000);
    }
    world.bumpFactor += (1 - world.bumpFactor) * Math.min(1, dt / 900);

    world.speed = (300 + progress * 150) * world.bumpFactor;
    var metresThisFrame = (world.speed * dt) / 1000 / PX_PER_METRE;
    world.distance += metresThisFrame;
    world.roadOffset += (world.speed * dt) / 1000;

    if (world.distance >= TARGET_DISTANCE) {
      world.distance = TARGET_DISTANCE;
      completeRide();
      return;
    }

    world.spawnTimer -= dt / 1000;
    if (world.spawnTimer <= 0) {
      spawnObstacle();
      var progressFactor = 1 - progress * 0.32;
      world.spawnTimer = randomBetween(0.82, 1.5) * progressFactor;
    }

    var height = canvas.clientHeight;
    var playerY = height - 64;

    for (var index = world.obstacles.length - 1; index >= 0; index--) {
      var obstacle = world.obstacles[index];
      obstacle.y += (world.speed * dt) / 1000;

      if (obstacle.y > height + 40) {
        world.obstacles.splice(index, 1);
        continue;
      }

      var obstacleX = laneX(obstacle.lane, canvas.clientWidth);
      var hitX = Math.abs(obstacleX - player.x) < 34;
      var hitY =
        obstacle.y > playerY - 46 && obstacle.y < playerY + 26;

      if (hitX && hitY) {
        bump(obstacleX, obstacle.y);
        world.obstacles.splice(index, 1);
      }
    }

    // Spark particles fly and fall with a little gravity.
    for (var p = world.bumpParticles.length - 1; p >= 0; p--) {
      var particle = world.bumpParticles[p];
      particle.age += dt / 1000;
      particle.x += (particle.vx * dt) / 1000;
      particle.y += (particle.vy * dt) / 1000;
      particle.vy += (320 * dt) / 1000;
      if (particle.age >= particle.life) {
        world.bumpParticles.splice(p, 1);
      }
    }

    // Floating hearts drift upward and fade.
    for (var f = world.floaters.length - 1; f >= 0; f--) {
      var floater = world.floaters[f];
      floater.age += dt / 1000;
      floater.y -= (40 * dt) / 1000;
      if (floater.age >= floater.life) {
        world.floaters.splice(f, 1);
      }
    }

    // Smooth lane change.
    player.targetX = laneX(player.lane, canvas.clientWidth);
    player.x += (player.targetX - player.x) * Math.min(1, dt / 110);
  }

  function drawStar(star, time, height) {
    var twinkle = 0.45 + 0.4 * Math.sin(time / 700 * star.speed + star.phase);
    ctx.globalAlpha = Math.max(0.12, twinkle);
    ctx.fillStyle = '#d9eaf5';
    ctx.beginPath();
    ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  function drawBackground(time) {
    var width = canvas.clientWidth;
    var height = canvas.clientHeight;
    var horizon = roadTop(height);

    var sky = ctx.createLinearGradient(0, 0, 0, horizon);
    sky.addColorStop(0, '#0a1128');
    sky.addColorStop(0.7, '#101b3d');
    sky.addColorStop(1, '#1a2f6b');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, width, horizon);

    stars.forEach(function (star) {
      drawStar(star, time, horizon);
    });

    // Moon
    var moonX = width * 0.82;
    var moonY = horizon * 0.26;
    var moonR = Math.min(26, width * 0.035);
    var moonGlow = ctx.createRadialGradient(moonX, moonY, moonR * 0.4, moonX, moonY, moonR * 4);
    moonGlow.addColorStop(0, 'rgba(217, 234, 245, 0.35)');
    moonGlow.addColorStop(1, 'rgba(217, 234, 245, 0)');
    ctx.fillStyle = moonGlow;
    ctx.fillRect(moonX - moonR * 4, moonY - moonR * 4, moonR * 8, moonR * 8);
    ctx.fillStyle = '#dcebf8';
    ctx.beginPath();
    ctx.arc(moonX, moonY, moonR, 0, Math.PI * 2);
    ctx.fill();

    // Distant hills
    ctx.fillStyle = '#14224e';
    ctx.beginPath();
    ctx.moveTo(0, horizon);
    ctx.lineTo(0, horizon - 26);
    ctx.quadraticCurveTo(width * 0.14, horizon - 62, width * 0.3, horizon - 24);
    ctx.quadraticCurveTo(width * 0.42, horizon - 4, width * 0.52, horizon - 18);
    ctx.quadraticCurveTo(width * 0.68, horizon - 48, width * 0.84, horizon - 16);
    ctx.quadraticCurveTo(width * 0.93, horizon - 2, width, horizon - 22);
    ctx.lineTo(width, horizon);
    ctx.closePath();
    ctx.fill();
  }

  function drawRoad() {
    var width = canvas.clientWidth;
    var height = canvas.clientHeight;
    var horizon = roadTop(height);

    var grass = ctx.createLinearGradient(0, horizon, 0, height);
    grass.addColorStop(0, '#16244f');
    grass.addColorStop(1, '#0d1734');
    ctx.fillStyle = grass;
    ctx.fillRect(0, horizon, width, height - horizon);

    var roadLeft = width * 0.16;
    var roadRight = width * 0.84;

    var road = ctx.createLinearGradient(0, horizon, 0, height);
    road.addColorStop(0, '#1b2750');
    road.addColorStop(0.4, '#141f42');
    road.addColorStop(1, '#0f1834');
    ctx.fillStyle = road;
    ctx.fillRect(roadLeft, horizon, roadRight - roadLeft, height - horizon);

    // Road edges
    ctx.fillStyle = 'rgba(185, 221, 240, 0.5)';
    ctx.fillRect(roadLeft - 3, horizon, 3, height - horizon);
    ctx.fillRect(roadRight, horizon, 3, height - horizon);

    // Lane dashes (scrolling towards the rider)
    var laneWidth = (roadRight - roadLeft) / LANE_COUNT;
    var dashSpacing = 64;
    var offset = world.roadOffset % dashSpacing;

    ctx.fillStyle = 'rgba(169, 203, 234, 0.4)';
    for (var lane = 1; lane < LANE_COUNT; lane++) {
      var x = roadLeft + laneWidth * lane - 1.5;
      for (var y = horizon - dashSpacing + offset; y < height; y += dashSpacing) {
        ctx.fillRect(x, y, 3, 30);
      }
    }

    // Roadside trees + glow posts
    var spacing = 170;
    var treeOffset = world.roadOffset % spacing;

    for (var slot = 0; slot < Math.ceil(height / spacing) + 2; slot++) {
      var yPosition = horizon - spacing + slot * spacing + (treeOffset % spacing);

      [roadLeft - 34, roadRight + 34].forEach(function (xPosition, sideIndex) {
        // Pine silhouette
        ctx.fillStyle = '#12204a';
        ctx.beginPath();
        ctx.moveTo(xPosition, yPosition - 34);
        ctx.lineTo(xPosition + 13, yPosition + 8);
        ctx.lineTo(xPosition - 13, yPosition + 8);
        ctx.closePath();
        ctx.fill();

        // Glowing post light
        ctx.fillStyle = 'rgba(79, 142, 219, 0.85)';
        ctx.beginPath();
        ctx.arc(xPosition + (sideIndex === 0 ? 22 : -22), yPosition - 2, 2.4, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = 'rgba(79, 142, 219, 0.16)';
        ctx.beginPath();
        ctx.arc(xPosition + (sideIndex === 0 ? 22 : -22), yPosition - 2, 9, 0, Math.PI * 2);
        ctx.fill();
      });
    }
  }

  function drawObstacles() {
    var width = canvas.clientWidth;

    world.obstacles.forEach(function (obstacle) {
      var x = laneX(obstacle.lane, width);

      if (obstacle.type === 'cone') {
        ctx.fillStyle = '#e8963f';
        ctx.beginPath();
        ctx.moveTo(x, obstacle.y - 20);
        ctx.lineTo(x + 12, obstacle.y + 10);
        ctx.lineTo(x - 12, obstacle.y + 10);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
        ctx.fillRect(x - 8, obstacle.y - 6, 16, 4);

        ctx.fillStyle = 'rgba(232, 150, 63, 0.9)';
        ctx.fillRect(x - 13, obstacle.y + 10, 26, 4);
      } else {
        // Barrier
        ctx.fillStyle = '#24439b';
        ctx.fillRect(x - 26, obstacle.y - 12, 52, 18);
        ctx.fillStyle = 'rgba(217, 234, 245, 0.85)';
        for (var stripe = -1; stripe <= 1; stripe++) {
          ctx.save();
          ctx.beginPath();
          ctx.rect(x - 26, obstacle.y - 12, 52, 18);
          ctx.clip();
          ctx.translate(stripe * 18, 0);
          ctx.rotate(0.5);
          ctx.fillRect(x - 8, obstacle.y - 20, 7, 36);
          ctx.restore();
        }
        ctx.fillStyle = 'rgba(23, 43, 101, 0.9)';
        ctx.fillRect(x - 24, obstacle.y + 6, 5, 10);
        ctx.fillRect(x + 19, obstacle.y + 6, 5, 10);
      }
    });
  }

  function drawMotorcycle(time) {
    var width = canvas.clientWidth;
    var height = canvas.clientHeight;
    var x = player.x;
    var y = height - 64;

    // Headlight beam
    var beam = ctx.createLinearGradient(0, y - 130, 0, y);
    beam.addColorStop(0, 'rgba(217, 234, 245, 0)');
    beam.addColorStop(1, 'rgba(217, 234, 245, 0.1)');
    ctx.fillStyle = beam;
    ctx.beginPath();
    ctx.moveTo(x - 6, y - 58);
    ctx.lineTo(x - 30, y - 150);
    ctx.lineTo(x + 30, y - 150);
    ctx.lineTo(x + 6, y - 58);
    ctx.closePath();
    ctx.fill();

    // Rear tyre
    ctx.fillStyle = '#0b1226';
    ctx.beginPath();
    ctx.arc(x, y, 15, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#233158';
    ctx.beginPath();
    ctx.arc(x, y, 6, 0, Math.PI * 2);
    ctx.fill();

    // Rear fender
    ctx.strokeStyle = '#4f8edb';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(x, y, 19, Math.PI * 1.08, Math.PI * 1.92);
    ctx.stroke();

    // Exhaust (classic right-side thumper pipe)
    ctx.strokeStyle = '#8fa8c8';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(x + 12, y - 22);
    ctx.lineTo(x + 24, y - 4);
    ctx.stroke();

    // Saddlebags / tail section
    ctx.fillStyle = '#1e2f66';
    ctx.beginPath();
    if (ctx.roundRect) {
      ctx.roundRect(x - 16, y - 34, 32, 16, 6);
    } else {
      ctx.rect(x - 16, y - 34, 32, 16);
    }
    ctx.fill();

    // Tail lamp glow
    ctx.fillStyle = 'rgba(217, 234, 245, 0.9)';
    ctx.beginPath();
    ctx.arc(x, y - 30, 3.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(217, 234, 245, 0.25)';
    ctx.beginPath();
    ctx.arc(x, y - 30, 9, 0, Math.PI * 2);
    ctx.fill();

    // Rider body
    ctx.fillStyle = '#24439b';
    ctx.beginPath();
    ctx.ellipse(x, y - 48, 13, 18, 0, 0, Math.PI * 2);
    ctx.fill();

    // Reflective jacket stripe
    ctx.strokeStyle = 'rgba(185, 221, 240, 0.65)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x - 11, y - 44);
    ctx.lineTo(x + 11, y - 44);
    ctx.stroke();

    // Arms reaching the handlebars
    ctx.strokeStyle = '#1d3474';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(x - 10, y - 54);
    ctx.lineTo(x - 22, y - 64);
    ctx.moveTo(x + 10, y - 54);
    ctx.lineTo(x + 22, y - 64);
    ctx.stroke();

    // Handlebars + grips
    ctx.strokeStyle = '#8fa8c8';
    ctx.lineWidth = 3.4;
    ctx.beginPath();
    ctx.moveTo(x - 26, y - 66);
    ctx.lineTo(x + 26, y - 66);
    ctx.stroke();
    ctx.fillStyle = '#101b3d';
    ctx.beginPath();
    ctx.arc(x - 26, y - 66, 3.6, 0, Math.PI * 2);
    ctx.arc(x + 26, y - 66, 3.6, 0, Math.PI * 2);
    ctx.fill();

    // Helmet
    var bob = Math.sin(time / 130) * 1.1;
    ctx.fillStyle = '#172b65';
    ctx.beginPath();
    ctx.arc(x, y - 76 + bob, 10.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(185, 221, 240, 0.35)';
    ctx.beginPath();
    ctx.arc(x - 3, y - 79 + bob, 3.4, 0, Math.PI * 2);
    ctx.fill();
  }

  function drawSpeedLines() {
    var width = canvas.clientWidth;
    var height = canvas.clientHeight;
    var progress = world.distance / TARGET_DISTANCE;

    if (progress < 0.7) {
      return;
    }

    var intensity = (progress - 0.7) / 0.3;
    ctx.strokeStyle = 'rgba(127, 166, 232, ' + (0.14 * intensity).toFixed(3) + ')';
    ctx.lineWidth = 2;

    for (var index = 0; index < 6; index++) {
      var x = ((index * 173 + world.roadOffset * 3.7) % (width + 80)) - 40;
      var y = ((index * 97 + world.roadOffset * 1.9) % height);
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x, y + 34 + 26 * intensity);
      ctx.stroke();
    }
  }

  function drawBumpEffects() {
    world.bumpParticles.forEach(function (particle) {
      ctx.globalAlpha = Math.max(0, 1 - particle.age / particle.life);
      ctx.fillStyle = '#d9eaf5';
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.r, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;

    world.floaters.forEach(function (floater) {
      ctx.globalAlpha = Math.max(0, 1 - floater.age / floater.life);
      ctx.font = '22px "Segoe UI Emoji", "Apple Color Emoji", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(floater.text, floater.x, floater.y);
    });
    ctx.globalAlpha = 1;
    ctx.textAlign = 'start';
  }

  function updateHud() {
    if (hud.distance) {
      hud.distance.textContent = Math.round(world.distance) + ' m';
    }
    if (hud.progress) {
      var percent = Math.min(100, (world.distance / TARGET_DISTANCE) * 100);
      hud.progress.style.width = percent + '%';
    }
  }

  function loop(time) {
    rafId = null;

    if (state !== 'running') {
      return;
    }

    var dt = Math.min(MAX_DT, time - lastFrameTime);
    lastFrameTime = time;

    update(dt);

    if (ctx) {
      // A bump makes the whole scene shake for a moment.
      var shake = world.bumpTimer > 0 ? 3 : 0;
      ctx.save();
      if (shake) {
        ctx.translate(randomBetween(-shake, shake), randomBetween(-shake, shake));
      }
      drawBackground(time);
      drawRoad();
      drawObstacles();
      drawMotorcycle(time);
      drawSpeedLines();
      drawBumpEffects();
      ctx.restore();
    }

    updateHud();

    if (state === 'running') {
      rafId = window.requestAnimationFrame(loop);
    }
  }

  function moveLane(delta) {
    if (state !== 'running') {
      return;
    }
    player.lane = Math.max(0, Math.min(LANE_COUNT - 1, player.lane + delta));
  }

  function setupControls() {
    window.addEventListener('keydown', function (event) {
      if (state !== 'running') {
        return;
      }

      var key = event.key;
      var handled = true;

      if (key === 'ArrowLeft' || key === 'a' || key === 'A') {
        moveLane(-1);
      } else if (key === 'ArrowRight' || key === 'd' || key === 'D') {
        moveLane(1);
      } else {
        handled = false;
      }

      if (handled) {
        event.preventDefault();
      }
    });

    var leftButton = document.getElementById('game-left');
    var rightButton = document.getElementById('game-right');

    if (leftButton) {
      leftButton.addEventListener('click', function () {
        moveLane(-1);
      });
    }

    if (rightButton) {
      rightButton.addEventListener('click', function () {
        moveLane(1);
      });
    }

    if (canvas) {
      canvas.addEventListener('touchstart', function (event) {
        if (state !== 'running') {
          return;
        }
        var touch = event.touches[0];
        if (!touch) {
          return;
        }
        var bounds = canvas.getBoundingClientRect();
        var relativeX = touch.clientX - bounds.left;
        moveLane(relativeX < bounds.width / 2 ? -1 : 1);
        event.preventDefault();
      }, { passive: false });
    }
  }

  function setupButtons() {
    var startButton = document.getElementById('game-start-button');
    var continueButton = document.getElementById('game-continue-button');
    var counterSection = document.getElementById('counter');

    if (startButton) {
      startButton.addEventListener('click', startRide);
    }

    if (continueButton && counterSection) {
      continueButton.addEventListener('click', function () {
        unlockCounter();
        counterSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }
  }

  function cacheDom() {
    shell = document.getElementById('game-shell');
    canvas = document.getElementById('game-canvas');
    overlays = {
      start: document.getElementById('game-overlay-start'),
      complete: document.getElementById('game-overlay-complete'),
      none: null
    };
    hud = {
      distance: document.getElementById('game-distance'),
      progress: document.getElementById('game-progress'),
      target: document.getElementById('game-target')
    };

    if (hud.target) {
      hud.target.textContent = TARGET_DISTANCE + ' m';
    }
  }

  function initGame() {
    cacheDom();

    if (!canvas || !shell) {
      return;
    }

    ctx = canvas.getContext('2d');
    resizeCanvas();
    drawIdleScene();

    setupControls();
    setupButtons();

    window.addEventListener('resize', function () {
      resizeCanvas();
      if (state === 'idle') {
        drawIdleScene();
      }
    });
  }

  function drawIdleScene() {
    if (!ctx) {
      return;
    }
    drawBackground(0);
    drawRoad();
    drawMotorcycle(0);
  }

  window.MemoriesGame = {
    init: initGame,
    start: startRide,
    isCounterUnlocked: isCounterUnlocked,
    getStatus: function () {
      return {
        state: state,
        distance: world.distance,
        target: TARGET_DISTANCE,
        bumps: world.bumpCount,
        playerLane: player.lane,
        playerX: player.x,
        obstacles: world.obstacles.map(function (obstacle) {
          return { lane: obstacle.lane, y: obstacle.y };
        })
      };
    }
  };
})();
