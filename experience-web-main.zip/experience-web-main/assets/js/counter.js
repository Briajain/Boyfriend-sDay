(function () {
  // Our story began on 22 April 2026 at 9:48 AM IST (Asia/Kolkata).
  var RELATIONSHIP_START_ISO = '2026-04-22T09:48:00+05:30';
  var TIME_ZONE = 'Asia/Kolkata';

  var RELATIONSHIP_START = new Date(RELATIONSHIP_START_ISO);

  var relationshipStartInZone = {
    year: 2026,
    month: 4,
    day: 22,
    hour: 9,
    minute: 48,
    second: 0
  };

  var dateTimeFormatter = null;
  if (typeof Intl !== 'undefined' && Intl.DateTimeFormat) {
    try {
      dateTimeFormatter = new Intl.DateTimeFormat('en-GB', {
        timeZone: TIME_ZONE,
        hour12: false,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
    } catch (error) {
      dateTimeFormatter = null;
    }
  }

  function pad2(number) {
    return String(number).padStart(2, '0');
  }

  function getNowInZone(date) {
    if (!dateTimeFormatter) {
      // Fallback: use the visitor's local clock (best effort).
      return {
        year: date.getFullYear(),
        month: date.getMonth() + 1,
        day: date.getDate(),
        hour: date.getHours(),
        minute: date.getMinutes(),
        second: date.getSeconds()
      };
    }

    var parts = dateTimeFormatter.formatToParts(date);
    var values = {};

    parts.forEach(function (part) {
      if (part.type !== 'literal') {
        values[part.type] = parseInt(part.value, 10);
      }
    });

    // Some environments render midnight as "24" with hour12: false.
    if (values.hour === 24) {
      values.hour = 0;
    }

    return {
      year: values.year,
      month: values.month,
      day: values.day,
      hour: values.hour,
      minute: values.minute,
      second: values.second
    };
  }

  function daysInMonth(year, month) {
    // month is 1-based; day 0 of the next month = last day of this month.
    return new Date(Date.UTC(year, month, 0)).getUTCDate();
  }

  function calculateElapsed(start, now) {
    var years = now.year - start.year;
    var months = now.month - start.month;
    var days = now.day - start.day;
    var hours = now.hour - start.hour;
    var minutes = now.minute - start.minute;
    var seconds = now.second - start.second;

    if (seconds < 0) {
      seconds += 60;
      minutes -= 1;
    }

    if (minutes < 0) {
      minutes += 60;
      hours -= 1;
    }

    if (hours < 0) {
      hours += 24;
      days -= 1;
    }

    if (days < 0) {
      // Borrow the length of the month before `now`'s month
      // (handles 28/29/30/31-day months and leap years).
      var previousMonth = now.month - 1;
      var previousMonthYear = now.year;
      if (previousMonth < 1) {
        previousMonth = 12;
        previousMonthYear -= 1;
      }
      days += daysInMonth(previousMonthYear, previousMonth);
      months -= 1;
    }

    if (months < 0) {
      years -= 1;
      months += 12;
    }

    return {
      years: Math.max(0, years),
      months: Math.max(0, months),
      days: Math.max(0, days),
      hours: Math.max(0, hours),
      minutes: Math.max(0, minutes),
      seconds: Math.max(0, seconds)
    };
  }

  function setText(id, value) {
    var element = document.getElementById(id);
    if (element) {
      element.textContent = value;
    }
  }

  function updateCounter() {
    var now = new Date();
    var elapsed = calculateElapsed(relationshipStartInZone, getNowInZone(now));

    setText('counter-years', String(elapsed.years));
    setText('counter-months', String(elapsed.months));
    setText('counter-days', String(elapsed.days));
    setText('counter-hours', pad2(elapsed.hours));
    setText('counter-minutes', pad2(elapsed.minutes));
    setText('counter-seconds', pad2(elapsed.seconds));

    var totalDays = Math.floor(
      Math.max(0, now.getTime() - RELATIONSHIP_START.getTime()) / 86400000
    );
    setText('summary-years', String(elapsed.years));
    setText('summary-months', String(elapsed.months));
    setText('summary-days', String(elapsed.days));
    setText('summary-total-days', String(totalDays));
  }

  function initCounter() {
    updateCounter();
    window.setInterval(updateCounter, 1000);
  }

  window.MemoriesCounter = {
    init: initCounter
  };
})();
