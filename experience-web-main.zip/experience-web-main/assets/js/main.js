(function () {
  var letterFallbackData = {
    badge: '3 October — Boyfriend’s Day',
    signature: 'CuteLittleGangster',
    paragraphs: [
      'My Dearest,',
      'Today is National Boyfriend’s Day, and while it might sound like just another entry on a calendar, it gives me the gentlest, sweetest excuse to pause the rush of everyday life and focus entirely on you. If I were to sit beside you right now, I might hand you a written note wrapped in a ribbon, but even paper feels small when I try to capture everything you mean to me. So take a quiet breath, make yourself comfortable, and let me tell you what it feels like to love you.',
      'When I look back at my life before you arrived, it wasn\'t empty, but it certainly lacked the color and warmth that you brought with you. You entered my world not like a storm, but like the first light of a quiet dawn—softly, steadily, and with a warmth that cleared away every shadow I didn’t even realize I was carrying. Over time, you have become my favorite part of every day, the calm in my busiest moments, and the steady anchor that holds me grounded no matter how wildly the world turns outside.',
      'What I love most about us isn\'t just the grand milestones, the beautiful dates, or the celebration days like today. It’s the quiet, unwritten magic woven into our ordinary routine. It’s the way your eyes crinkle at the corners when you laugh at something silly, the sound of your voice when you speak passionately about something you care about, and the comforting reassurance of your hand sliding into mine. You have this incredible ability to turn the simplest moments—a quiet cup of coffee, a late-night drive, or just sitting side by side in complete silence—into memories that I carry around like treasures.',
      'You are my safest space. In a world that often demands so much, where we constantly have to put on brave faces and keep up with expectations, being with you feels like finally coming home. With you, I don\'t have to pretend, hide my flaws, or pretend to be stronger than I am. You see me completely—my joys, my worries, my quirks, and my vulnerabilities—and you accept every single piece of me with infinite patience and understanding. To be loved by you is to know what true acceptance feels like, and that is a gift I will never take for granted.',
      'I admire so much about who you are as a person. I see your devotion, your integrity, your strength, and the quiet kindness you show not just to me, but to everyone around you. You tackle challenges with grace, you work tirelessly for the things you believe in, and yet you never lose that soft, playful heart that makes you so uniquely *you*. You inspire me to be a better person every day—not because you ever demand it, but simply because watching you live your life makes me want to reach higher, love deeper, and dream bigger.',
      'Thank you for all the little things you do that often go unspoken. Thank you for listening when I need to vent, even if it\'s about something small. Thank you for the subtle checks to see if I’m okay, the unexpected hugs when I look tired, and the way you always make sure I feel seen, heard, and cherished. Love isn\'t just a feeling; it’s a choice made thousands of times a day in small, thoughtful actions, and you choose to love me so beautifully every single day.',
      'As we celebrate today, I find myself looking forward with so much hope and excitement. I think about all the chapters we have yet to write together: the journeys we haven\'t taken, the quiet mornings we have yet to share, the challenges we will face hand-in-hand, and the endless laughs waiting for us down the road. Life is unpredictable, but the one constant I feel absolute certainty about is my love for you. Whatever comes our way, knowing that I get to navigate it with you as my partner, my best friend, and my boyfriend fills me with a profound sense of peace.',
      'Thank you for being my anchor, my confidant, my favorite companion, and my greatest comfort. Thank you for choosing me, for holding my heart so gently, and for being the incredible man that you are. On this Boyfriend’s Day and every day after, I want you to remember that you are deeply, unconditionally, and endlessly loved.',
      'Happy Boyfriend’s Day, my love. Here is to us, to today, and to all our tomorrows.',
      'Forever and always yours,'
    ]
  };

  function appendTextWithEmphasis(paragraphElement, text) {
    var parts = String(text).split(/\*([^*]+)\*/g);
    parts.forEach(function (part, index) {
      if (!part) {
        return;
      }
      if (index % 2 === 1) {
        var emphasis = document.createElement('em');
        emphasis.textContent = part;
        paragraphElement.appendChild(emphasis);
      } else {
        paragraphElement.appendChild(document.createTextNode(part));
      }
    });
  }

  function applyLetter(data) {
    var badge = document.getElementById('letter-badge');
    var content = document.getElementById('letter-content');
    var signature = document.getElementById('letter-signature');

    if (badge && data.badge) {
      badge.textContent = data.badge;
    }

    if (content && Array.isArray(data.paragraphs)) {
      content.innerHTML = '';
      data.paragraphs.forEach(function (paragraph, index) {
        var paragraphElement = document.createElement('p');
        paragraphElement.className = 'letter__paragraph';
        paragraphElement.style.setProperty('--delay', Math.min(index * 70, 700) + 'ms');
        appendTextWithEmphasis(paragraphElement, paragraph);
        content.appendChild(paragraphElement);
      });
    }

    if (signature && data.signature) {
      signature.textContent = data.signature;
    }
  }

  function renderLetter() {
    fetch('assets/data/letter.json')
      .then(function (response) {
        if (!response.ok) {
          throw new Error('letter unavailable');
        }
        return response.json();
      })
      .then(applyLetter)
      .catch(function () {
        applyLetter(letterFallbackData);
      });
  }

  function setupLetterEnvelope() {
    var openButton = document.getElementById('open-letter-button');
    var envelopeScene = document.getElementById('envelope-scene');
    var letterSection = document.getElementById('letter');
    var letterCard = document.getElementById('letter-card');

    if (!openButton || !envelopeScene || !letterCard || !letterSection) {
      return;
    }

    var isOpen = false;
    var closeTimer = null;

    function applyOpenHeight() {
      var letterSpace = Math.min(window.innerHeight * 0.68, 820);
      envelopeScene.style.minHeight = Math.max(620, letterSpace + 220) + 'px';
    }

    function clearDynamicHeight() {
      envelopeScene.style.removeProperty('min-height');
    }

    function openLetter() {
      if (closeTimer) {
        window.clearTimeout(closeTimer);
        closeTimer = null;
      }

      applyOpenHeight();
      letterSection.classList.add('section--letter-open');
      envelopeScene.classList.remove('envelope-scene--closing');
      envelopeScene.classList.add('envelope-scene--open');
      openButton.textContent = 'Close the Letter';
      openButton.setAttribute('aria-expanded', 'true');
      isOpen = true;
    }

    function closeLetter() {
      letterSection.classList.remove('section--letter-open');
      envelopeScene.classList.add('envelope-scene--closing');
      envelopeScene.classList.remove('envelope-scene--open');
      openButton.textContent = 'Open the Letter';
      openButton.setAttribute('aria-expanded', 'false');
      isOpen = false;
      clearDynamicHeight();

      closeTimer = window.setTimeout(function () {
        envelopeScene.classList.remove('envelope-scene--closing');
      }, 760);
    }

    function toggleLetter() {
      if (isOpen) {
        closeLetter();
      } else {
        openLetter();
      }
    }

    openButton.addEventListener('click', toggleLetter);

    letterCard.addEventListener('click', function () {
      if (isOpen) {
        closeLetter();
      }
    });

    window.addEventListener('resize', function () {
      if (isOpen) {
        applyOpenHeight();
      }
    });
  }

  function setupMusicPlayer() {
    var player = document.getElementById('music-player');
    var toggleButton = document.getElementById('music-toggle');
    var card = document.getElementById('music-card');
    var closeButton = document.getElementById('music-close');
    var iframe = document.getElementById('spotify-embed');

    if (!player || !toggleButton || !card || !closeButton) {
      return;
    }

    var embedLoaded = false;

    function loadEmbed() {
      if (embedLoaded || !iframe) {
        return;
      }
      var source = iframe.getAttribute('data-src');
      if (source) {
        iframe.setAttribute('src', source);
        embedLoaded = true;
      }
    }

    function expandPlayer() {
      loadEmbed();
      card.hidden = false;
      toggleButton.setAttribute('aria-expanded', 'true');
    }

    function collapsePlayer() {
      card.hidden = true;
      toggleButton.setAttribute('aria-expanded', 'false');
    }

    toggleButton.addEventListener('click', function () {
      if (card.hidden) {
        expandPlayer();
      } else {
        collapsePlayer();
      }
    });

    closeButton.addEventListener('click', collapsePlayer);

    window.MemoriesMusic = {
      reveal: function () {
        player.classList.remove('music-player--hidden');
        toggleButton.classList.add('is-pulsing');
        if (window.matchMedia('(min-width: 900px)').matches) {
          expandPlayer();
        }
      }
    };
  }

  function setupIntroGate() {
    var overlay = document.getElementById('intro-gate');
    var startButton = document.getElementById('start-experience');

    if (!overlay || !startButton) {
      return;
    }

    var experienceStarted = false;

    function revealMainExperience() {
      overlay.classList.add('intro-overlay--leaving');
      overlay.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('experience-locked');
      document.body.classList.add('experience-unlocked');

      if (window.MemoriesMusic && window.MemoriesMusic.reveal) {
        window.MemoriesMusic.reveal();
      }

      window.setTimeout(function () {
        overlay.hidden = true;
      }, 900);
    }

    function startExperience() {
      if (experienceStarted) {
        return;
      }

      experienceStarted = true;
      startButton.disabled = true;
      startButton.setAttribute('aria-busy', 'true');

      window.setTimeout(function () {
        startButton.removeAttribute('aria-busy');
        revealMainExperience();
      }, 250);
    }

    startButton.addEventListener('click', startExperience);
  }

  function setupLockedNavLinks() {
    var counterLink = document.getElementById('nav-counter-link');
    var counterSection = document.getElementById('counter');
    var rideButton = document.getElementById('lock-ride-button');
    var gameSection = document.getElementById('game');

    function isLocked() {
      return !!(counterSection && counterSection.classList.contains('is-locked'));
    }

    function goRide() {
      if (gameSection) {
        gameSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }

    if (counterLink) {
      counterLink.addEventListener('click', function (event) {
        if (isLocked()) {
          event.preventDefault();
          goRide();
        }
      });
    }

    if (rideButton) {
      rideButton.addEventListener('click', goRide);
    }
  }

  function setupHeroRideButton() {
    var rideButton = document.getElementById('hero-ride-button');
    var gameSection = document.getElementById('game');

    if (!rideButton || !gameSection) {
      return;
    }

    rideButton.addEventListener('click', function () {
      gameSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  }

  function setupBackToTop() {
    var backButton = document.getElementById('back-to-top');
    var start = document.getElementById('hero');

    if (!backButton || !start) {
      return;
    }

    backButton.addEventListener('click', function () {
      start.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  }

  function initProject() {
    if (window.MemoriesIntro) window.MemoriesIntro.init();
    if (window.MemoriesGame) window.MemoriesGame.init();
    if (window.MemoriesCounter) window.MemoriesCounter.init();
    if (window.MemoriesEffects) window.MemoriesEffects.init();
    if (window.MemoriesMeteors) window.MemoriesMeteors.init();

    renderLetter();
    setupLetterEnvelope();
    setupMusicPlayer();
    setupIntroGate();
    setupLockedNavLinks();
    setupHeroRideButton();
    setupBackToTop();
  }

  document.addEventListener('DOMContentLoaded', initProject);
})();
